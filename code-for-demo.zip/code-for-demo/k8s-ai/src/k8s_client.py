"""Kubernetes client for querying cluster information"""

import logging
from typing import Dict, List, Any, Optional
from kubernetes import client, config, watch
from kubernetes.client.rest import ApiException
from datetime import datetime

logger = logging.getLogger(__name__)


class KubernetesClient:
    """Client for interacting with Kubernetes cluster"""

    def __init__(self, kubeconfig_path: Optional[str] = None, namespace: str = "default"):
        """Initialize Kubernetes client
        
        Args:
            kubeconfig_path: Path to kubeconfig file. If None, uses default
            namespace: Kubernetes namespace to query
        """
        try:
            if kubeconfig_path:
                config.load_kube_config(config_file=kubeconfig_path)
            else:
                config.load_kube_config()
        except config.ConfigException:
            logger.warning("Could not load kubeconfig, attempting in-cluster config")
            config.load_incluster_config()
        
        self.v1 = client.CoreV1Api()
        self.apps_v1 = client.AppsV1Api()
        self.namespace = namespace

    def get_pods(self, label_selector: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get all pods in namespace
        
        Args:
            label_selector: Optional label selector for filtering pods
            
        Returns:
            List of pod information dictionaries
        """
        try:
            pods = self.v1.list_namespaced_pod(
                namespace=self.namespace,
                label_selector=label_selector
            )
            
            pod_list = []
            for pod in pods.items:
                pod_info = {
                    "name": pod.metadata.name,
                    "namespace": pod.metadata.namespace,
                    "phase": pod.status.phase,
                    "created_at": pod.metadata.creation_timestamp,
                    "containers": []
                }
                
                # Extract container information
                for container in pod.spec.containers:
                    container_info = {
                        "name": container.name,
                        "image": container.image,
                        "ready": False
                    }
                    
                    # Check if container is ready
                    if pod.status.container_statuses:
                        for cont_status in pod.status.container_statuses:
                            if cont_status.name == container.name:
                                container_info["ready"] = cont_status.ready
                                break
                    
                    pod_info["containers"].append(container_info)
                
                pod_list.append(pod_info)
            
            return pod_list
        except ApiException as e:
            logger.error(f"Failed to get pods: {e}")
            return []

    def get_deployments(self) -> List[Dict[str, Any]]:
        """Get all deployments in namespace
        
        Returns:
            List of deployment information dictionaries
        """
        try:
            deployments = self.apps_v1.list_namespaced_deployment(
                namespace=self.namespace
            )
            
            deployment_list = []
            for deployment in deployments.items:
                deploy_info = {
                    "name": deployment.metadata.name,
                    "namespace": deployment.metadata.namespace,
                    "replicas": deployment.spec.replicas,
                    "ready_replicas": deployment.status.ready_replicas or 0,
                    "updated_replicas": deployment.status.updated_replicas or 0,
                    "available_replicas": deployment.status.available_replicas or 0,
                    "created_at": deployment.metadata.creation_timestamp,
                    "image": self._extract_image_from_deployment(deployment),
                }
                deployment_list.append(deploy_info)
            
            return deployment_list
        except ApiException as e:
            logger.error(f"Failed to get deployments: {e}")
            return []

    def get_statefulsets(self) -> List[Dict[str, Any]]:
        """Get all statefulsets in namespace
        
        Returns:
            List of statefulset information dictionaries
        """
        try:
            statefulsets = self.apps_v1.list_namespaced_stateful_set(
                namespace=self.namespace
            )
            
            statefulset_list = []
            for ss in statefulsets.items:
                ss_info = {
                    "name": ss.metadata.name,
                    "namespace": ss.metadata.namespace,
                    "replicas": ss.spec.replicas,
                    "ready_replicas": ss.status.ready_replicas or 0,
                    "created_at": ss.metadata.creation_timestamp,
                    "image": self._extract_image_from_statefulset(ss),
                }
                statefulset_list.append(ss_info)
            
            return statefulset_list
        except ApiException as e:
            logger.error(f"Failed to get statefulsets: {e}")
            return []

    def get_pod_logs(self, pod_name: str, container_name: Optional[str] = None, 
                     lines: int = 50) -> str:
        """Get logs from a pod
        
        Args:
            pod_name: Name of the pod
            container_name: Name of the container (optional, uses first if not specified)
            lines: Number of log lines to retrieve
            
        Returns:
            Pod logs as string
        """
        try:
            logs = self.v1.read_namespaced_pod_log(
                name=pod_name,
                namespace=self.namespace,
                container=container_name,
                tail_lines=lines
            )
            return logs
        except ApiException as e:
            logger.error(f"Failed to get pod logs: {e}")
            return f"Error retrieving logs: {e}"

    def get_pod_events(self, pod_name: str) -> List[Dict[str, Any]]:
        """Get events for a pod
        
        Args:
            pod_name: Name of the pod
            
        Returns:
            List of event information
        """
        try:
            events = self.v1.list_namespaced_event(
                namespace=self.namespace,
                field_selector=f"involvedObject.name={pod_name}"
            )
            
            event_list = []
            for event in events.items:
                event_info = {
                    "type": event.type,
                    "reason": event.reason,
                    "message": event.message,
                    "first_timestamp": event.first_timestamp,
                    "last_timestamp": event.last_timestamp,
                    "count": event.count,
                }
                event_list.append(event_info)
            
            return event_list
        except ApiException as e:
            logger.error(f"Failed to get pod events: {e}")
            return []

    def search_pod_by_app(self, app_name: str) -> List[Dict[str, Any]]:
        """Search pods by application name label
        
        Args:
            app_name: Application name to search for
            
        Returns:
            List of matching pods
        """
        label_selector = f"app={app_name}"
        return self.get_pods(label_selector=label_selector)

    def get_latest_deployment_time(self, deployment_name: str) -> Optional[datetime]:
        """Get the latest deployment/update time for a deployment
        
        Args:
            deployment_name: Name of the deployment
            
        Returns:
            Datetime of latest update or None
        """
        try:
            deployment = self.apps_v1.read_namespaced_deployment(
                name=deployment_name,
                namespace=self.namespace
            )
            
            # Get the most recent condition time
            if deployment.status.conditions:
                latest_time = max(
                    [cond.last_update_time for cond in deployment.status.conditions 
                     if cond.last_update_time],
                    default=None
                )
                return latest_time
            
            return deployment.metadata.creation_timestamp
        except ApiException as e:
            logger.error(f"Failed to get deployment time: {e}")
            return None

    @staticmethod
    def _extract_image_from_deployment(deployment) -> str:
        """Extract container image from deployment"""
        if deployment.spec.template.spec.containers:
            return deployment.spec.template.spec.containers[0].image
        return "N/A"

    @staticmethod
    def _extract_image_from_statefulset(statefulset) -> str:
        """Extract container image from statefulset"""
        if statefulset.spec.template.spec.containers:
            return statefulset.spec.template.spec.containers[0].image
        return "N/A"
