"""Chatbot Agent using LangChain and OpenAI"""

import logging
import os
from typing import Optional
from dotenv import load_dotenv
from src.k8s_client import KubernetesClient
from src.tools import K8sTools

# LangChain compatibility: prefer newer APIs but fall back to older ones
try:
    # Newer LangChain
    from langchain.agents import initialize_agent, AgentType  # type: ignore
    from langchain.tools import Tool  # type: ignore
    from langchain.chat_models import ChatOpenAI  # type: ignore
    HAS_NEW_LANGCHAIN = True
except Exception:
    # Fallback to older LangChain where available
    HAS_NEW_LANGCHAIN = False
    HAS_OLD_REACT = False
    try:
        # try to import create_react_agent variant
        from langchain.agents import create_react_agent, Tool  # type: ignore
        from langchain.prompts import PromptTemplate  # type: ignore
        HAS_OLD_REACT = True
    except Exception:
        HAS_OLD_REACT = False

    try:
        from langchain_openai import ChatOpenAI  # type: ignore
    except Exception:
        # ChatOpenAI may not be available; we'll handle at runtime
        ChatOpenAI = None  # type: ignore

logger = logging.getLogger(__name__)
load_dotenv()


class SimpleExecutor:
    """A small rule-based executor used when LangChain agent helpers are unavailable.

    It routes simple queries to `K8sTools` methods by matching keywords and deployment names.
    """

    def __init__(self, k8s_tools: K8sTools):
        self.k8s_tools = k8s_tools

    def _find_app_name(self, query: str) -> Optional[str]:
        # Try to find a deployment name mentioned in the query
        try:
            deployments = self.k8s_tools.k8s.get_deployments()
            names = [d.get('name', '').lower() for d in deployments]
            for name in names:
                if name and name in query:
                    return name
        except Exception:
            return None
        return None

    def run(self, query: str) -> str:
        q = (query or "").lower()
        app = self._find_app_name(q)

        if 'version' in q or 'image' in q:
            if app:
                return self.k8s_tools.get_app_version(app)
            return "Please specify the application name to check its version."

        if 'last' in q and 'deploy' in q or ('when' in q and 'deploy' in q):
            if app:
                return self.k8s_tools.get_last_deployment_time(app)
            return "Please specify the application name to find its last deployment time."

        if 'log' in q or 'logs' in q:
            if app:
                return self.k8s_tools.get_pod_logs_summary(app)
            return "Please specify the application name to retrieve logs."

        if 'health' in q or 'cluster health' in q:
            return self.k8s_tools.get_cluster_health()

        if 'application' in q or 'applications' in q or 'deployments' in q or 'running' in q:
            return self.k8s_tools.get_running_applications()

        if 'status' in q:
            if app:
                return self.k8s_tools.get_deployment_status(app)
            return self.k8s_tools.get_cluster_health()

        # Default: list running applications
        return self.k8s_tools.get_running_applications()


class K8sChatbotAgent:
    """Kubernetes Chatbot Agent using LangChain"""

    def __init__(self, openai_api_key: Optional[str] = None, 
                 kubeconfig_path: Optional[str] = None,
                 namespace: str = "default",
                 model: str = "gpt-4"):
        """Initialize the chatbot agent
        
        Args:
            openai_api_key: OpenAI API key (or uses OPENAI_API_KEY env var)
            kubeconfig_path: Path to kubeconfig file
            namespace: Kubernetes namespace to query
            model: OpenAI model to use
        """
        self.api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OpenAI API key not found. Set OPENAI_API_KEY environment variable.")
        
        # Initialize Kubernetes client
        self.k8s_client = KubernetesClient(kubeconfig_path=kubeconfig_path, namespace=namespace)
        self.k8s_tools = K8sTools(self.k8s_client)
        
        # Initialize LLM and tools depending on LangChain version
        if HAS_NEW_LANGCHAIN:
            self.llm = ChatOpenAI(
                model_name=model,
                temperature=0,
                openai_api_key=self.api_key,
            )

            # Initialize tools and agent using newer API
            self.tools = self._create_tools_new()
            self.executor = initialize_agent(
                tools=self.tools,
                llm=self.llm,
                agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
                verbose=True,
            )
        else:
            # Older LangChain API
            # Only build old-style tools if Tool is available; otherwise leave tools empty
            if 'Tool' in globals():
                self.tools = self._create_tools_old()
            else:
                self.tools = []

            # Create agent via create_react_agent and wrap with AgentExecutor when available
            if 'create_react_agent' in globals() and ChatOpenAI is not None:
                self.llm = ChatOpenAI(api_key=self.api_key, model=model, temperature=0)
                prompt = PromptTemplate.from_template(
                    """You are a helpful Kubernetes cluster assistant.\n\n{tools}\n\nQuestion: {input}\n\n{agent_scratchpad}"""
                )
                # create_react_agent may return an executor-like object already
                agent_obj = create_react_agent(self.llm, self.tools, prompt)
                try:
                    # Try to construct AgentExecutor if available
                    from langchain.agents import AgentExecutor as _AgentExecutor  # type: ignore

                    self.executor = _AgentExecutor.from_agent_and_tools(
                        agent=agent_obj,
                        tools=self.tools,
                        verbose=True,
                        handle_parsing_errors=True,
                        max_iterations=5,
                    )
                except Exception:
                    # Fall back to using the object returned by create_react_agent
                    self.executor = agent_obj
            else:
                # No create_react_agent/ChatOpenAI available: use SimpleExecutor fallback
                self.executor = SimpleExecutor(self.k8s_tools)

    def _create_tools_new(self) -> list:
        """Create tools for newer LangChain versions (Tool.from_function)."""
        tools = [
            Tool.from_function(
                func=self.k8s_tools.get_running_applications,
                name="GetRunningApplications",
                description="Get list of all running applications/deployments in the Kubernetes cluster",
            ),
            Tool.from_function(
                func=self.k8s_tools.get_app_version,
                name="GetAppVersion",
                description="Get the version/image tag of a specific application. Input: application name",
            ),
            Tool.from_function(
                func=self.k8s_tools.get_deployment_status,
                name="GetDeploymentStatus",
                description="Get the deployment status of an application including pod status. Input: application name",
            ),
            Tool.from_function(
                func=self.k8s_tools.get_last_deployment_time,
                name="GetLastDeploymentTime",
                description="Get when an application was last deployed. Input: application name",
            ),
            Tool.from_function(
                func=self.k8s_tools.get_pod_logs_summary,
                name="GetPodLogs",
                description="Get recent logs from application pods. Input: application name",
            ),
            Tool.from_function(
                func=self.k8s_tools.get_cluster_health,
                name="GetClusterHealth",
                description="Get overall Kubernetes cluster health status",
            ),
        ]
        return tools

    def _create_tools_old(self) -> list:
        """Create tools for older LangChain versions (Tool(...) constructor)."""
        tools = [
            Tool(
                name="GetRunningApplications",
                func=self.k8s_tools.get_running_applications,
                description="Get list of all running applications/deployments in the Kubernetes cluster",
            ),
            Tool(
                name="GetAppVersion",
                func=self.k8s_tools.get_app_version,
                description="Get the version/image tag of a specific application. Input: application name",
            ),
            Tool(
                name="GetDeploymentStatus",
                func=self.k8s_tools.get_deployment_status,
                description="Get the deployment status of an application including pod status. Input: application name",
            ),
            Tool(
                name="GetLastDeploymentTime",
                func=self.k8s_tools.get_last_deployment_time,
                description="Get when an application was last deployed. Input: application name",
            ),
            Tool(
                name="GetPodLogs",
                func=self.k8s_tools.get_pod_logs_summary,
                description="Get recent logs from application pods. Input: application name",
            ),
            Tool(
                name="GetClusterHealth",
                func=self.k8s_tools.get_cluster_health,
                description="Get overall Kubernetes cluster health status",
            ),
        ]
        return tools

    def _create_string_input_schema(self, param_name: str):
        """Create input schema for string parameter"""
        from pydantic import BaseModel, Field
        
        class StringInput(BaseModel):
            input: str = Field(description=param_name)
        
        return StringInput

    # Note: agent creation now uses `initialize_agent` in __init__

    def chat(self, user_query: str) -> str:
        """Process user query and return response
        
        Args:
            user_query: User's question about Kubernetes
            
        Returns:
            Response from the agent
        """
        try:
            # initialize_agent returns an AgentExecutor with a .run() method
            result = self.executor.run(user_query)
            return result or "Unable to process query"
        except Exception as e:
            logger.error(f"Error processing query: {e}")
            return f"Error: {str(e)}"

    def interactive_chat(self):
        """Run interactive chat session"""
        print("\n" + "="*60)
        print("Kubernetes Chatbot Agent")
        print("="*60)
        print("Type 'exit' to quit\n")
        
        while True:
            try:
                user_input = input("You: ").strip()
                
                if user_input.lower() == 'exit':
                    print("Goodbye!")
                    break
                
                if not user_input:
                    continue
                
                print("\nAgent processing...\n")
                response = self.chat(user_input)
                print(f"Agent: {response}\n")
                
            except KeyboardInterrupt:
                print("\n\nGoodbye!")
                break
            except Exception as e:
                print(f"Error: {e}")
