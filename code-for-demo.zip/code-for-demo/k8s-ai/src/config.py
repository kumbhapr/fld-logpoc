"""Configuration utilities for the chatbot"""

import os
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger(__name__)


class Config:
    """Configuration management"""
    
    # OpenAI Configuration
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4")
    
    # Kubernetes Configuration
    KUBECONFIG_PATH: Optional[str] = os.getenv("KUBECONFIG", None)
    K8S_NAMESPACE: str = os.getenv("K8S_NAMESPACE", "default")
    
    # Logging Configuration
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Agent Configuration
    AGENT_VERBOSE: bool = os.getenv("AGENT_VERBOSE", "false").lower() == "true"
    MAX_ITERATIONS: int = int(os.getenv("MAX_ITERATIONS", "5"))
    
    @classmethod
    def validate(cls) -> bool:
        """Validate configuration"""
        errors = []
        
        if not cls.OPENAI_API_KEY:
            errors.append("OPENAI_API_KEY is required")
        
        if cls.KUBECONFIG_PATH and not Path(cls.KUBECONFIG_PATH).exists():
            logger.warning(f"Specified kubeconfig not found: {cls.KUBECONFIG_PATH}")
        
        if errors:
            for error in errors:
                logger.error(error)
            return False
        
        return True
    
    @classmethod
    def print_config(cls):
        """Print configuration (excluding sensitive data)"""
        print("Configuration:")
        print(f"  OpenAI Model: {cls.OPENAI_MODEL}")
        print(f"  K8s Namespace: {cls.K8S_NAMESPACE}")
        print(f"  Log Level: {cls.LOG_LEVEL}")
        print(f"  Agent Verbose: {cls.AGENT_VERBOSE}")
