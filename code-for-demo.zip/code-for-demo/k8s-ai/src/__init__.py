"""Kubernetes Chatbot Agent"""

__version__ = "0.1.0"
