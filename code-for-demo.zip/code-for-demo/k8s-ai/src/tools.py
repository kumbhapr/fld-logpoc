"""Tools for the chatbot agent to query Kubernetes"""

import logging
from typing import Dict, Any, List
from src.k8s_client import KubernetesClient
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class K8sTools:
    """Tools for querying Kubernetes cluster information"""

    def __init__(self, k8s_client: KubernetesClient):
        """Initialize tools with Kubernetes client
        
        Args:
            k8s_client: KubernetesClient instance
        """
        self.k8s = k8s_client

    def get_running_applications(self) -> str:
        """Get all running applications in the cluster"""
        deployments = self.k8s.get_deployments()
        
        if not deployments:
            return "No deployments found in the cluster."
        
        response = "**Running Applications:**\n\n"
        for deploy in deployments:
            response += f"- **{deploy['name']}**\n"
            response += f"  - Image: {deploy['image']}\n"
            response += f"  - Replicas: {deploy['ready_replicas']}/{deploy['replicas']}\n"
            response += f"  - Status: {'Ready' if deploy['ready_replicas'] == deploy['replicas'] else 'Not Ready'}\n"
            response += f"  - Created: {deploy['created_at']}\n\n"
        
        return response

    def get_app_version(self, app_name: str) -> str:
        """Get the version/image of a specific application
        
        Args:
            app_name: Application name
            
        Returns:
            Human-readable version information
        """
        deployments = self.k8s.get_deployments()
        
        matching_deployments = [d for d in deployments if app_name.lower() in d['name'].lower()]
        
        if not matching_deployments:
            return f"Application '{app_name}' not found in deployments."
        
        response = f"**{app_name} Version Information:**\n\n"
        for deploy in matching_deployments:
            # Parse image to extract version
            image = deploy['image']
            version = image.split(':')[-1] if ':' in image else "latest"
            
            response += f"- **Deployment**: {deploy['name']}\n"
            response += f"  - Full Image: {image}\n"
            response += f"  - Version: {version}\n"
            response += f"  - Status: {'Running' if deploy['ready_replicas'] > 0 else 'Not Running'}\n"
            response += f"  - Ready Replicas: {deploy['ready_replicas']}/{deploy['replicas']}\n\n"
        
        return response

    def get_deployment_status(self, app_name: str) -> str:
        """Get the deployment status of an application
        
        Args:
            app_name: Application name
            
        Returns:
            Human-readable status
        """
        pods = self.k8s.search_pod_by_app(app_name)
        
        if not pods:
            # Try searching in deployment names
            deployments = self.k8s.get_deployments()
            matching = [d for d in deployments if app_name.lower() in d['name'].lower()]
            
            if not matching:
                return f"No deployment or pods found for '{app_name}'."
            
            response = f"**{app_name} Deployment Status:**\n\n"
            for deploy in matching:
                status = "✓ Healthy" if deploy['ready_replicas'] == deploy['replicas'] else "✗ Unhealthy"
                response += f"- **{deploy['name']}**: {status}\n"
                response += f"  - Replicas: {deploy['ready_replicas']}/{deploy['replicas']}\n"
                response += f"  - Updated: {deploy['updated_replicas']}/{deploy['replicas']}\n"
                response += f"  - Available: {deploy['available_replicas']}/{deploy['replicas']}\n\n"
            
            return response
        
        response = f"**{app_name} Pod Status:**\n\n"
        for pod in pods:
            response += f"- **{pod['name']}**\n"
            response += f"  - Status: {pod['phase']}\n"
            response += f"  - Containers: {len(pod['containers'])}\n"
            for container in pod['containers']:
                response += f"    - {container['name']}: {container['image']} ({'Ready' if container['ready'] else 'Not Ready'})\n"
            response += f"  - Created: {pod['created_at']}\n\n"
        
        return response

    def get_last_deployment_time(self, app_name: str) -> str:
        """Get when an application was last deployed
        
        Args:
            app_name: Application name
            
        Returns:
            Human-readable deployment time
        """
        deployments = self.k8s.get_deployments()
        matching = [d for d in deployments if app_name.lower() in d['name'].lower()]
        
        if not matching:
            return f"Application '{app_name}' not found."
        
        response = f"**{app_name} Deployment History:**\n\n"
        for deploy in matching:
            deployment_time = deploy['created_at']
            
            # Calculate time difference
            if deployment_time:
                now = datetime.utcnow().replace(tzinfo=deployment_time.tzinfo) if deployment_time.tzinfo else datetime.utcnow()
                time_diff = now - deployment_time
                
                # Format human-readable time
                if time_diff.days > 0:
                    time_str = f"{time_diff.days} days ago"
                else:
                    hours = time_diff.seconds // 3600
                    minutes = (time_diff.seconds % 3600) // 60
                    if hours > 0:
                        time_str = f"{hours} hours, {minutes} minutes ago"
                    else:
                        time_str = f"{minutes} minutes ago"
            else:
                time_str = "Unknown"
            
            response += f"- **{deploy['name']}**\n"
            response += f"  - First Deployed: {deployment_time}\n"
            response += f"  - Time Ago: {time_str}\n"
            response += f"  - Current Status: {'✓ Running' if deploy['ready_replicas'] > 0 else '✗ Not Running'}\n\n"
        
        return response

    def get_pod_logs_summary(self, app_name: str, lines: int = 20) -> str:
        """Get recent logs from application pods
        
        Args:
            app_name: Application name
            lines: Number of log lines to retrieve
            
        Returns:
            Human-readable logs
        """
        pods = self.k8s.search_pod_by_app(app_name)
        
        if not pods:
            return f"No pods found for application '{app_name}'."
        
        response = f"**Recent Logs for {app_name}:**\n\n"
        
        for pod in pods[:3]:  # Limit to first 3 pods
            response += f"**Pod: {pod['name']}**\n"
            response += "```\n"
            
            for container in pod['containers']:
                logs = self.k8s.get_pod_logs(pod['name'], container['name'], lines=lines)
                response += f"--- Container: {container['name']} ---\n"
                response += logs[:500]  # Limit log output
                response += "\n...\n"
            
            response += "```\n\n"
        
        return response

    def get_cluster_health(self) -> str:
        """Get overall cluster health status"""
        deployments = self.k8s.get_deployments()
        pods = self.k8s.get_pods()
        
        if not deployments and not pods:
            return "Cluster appears to be empty or not accessible."
        
        healthy_deployments = sum(1 for d in deployments if d['ready_replicas'] == d['replicas'])
        total_deployments = len(deployments)
        
        healthy_pods = sum(1 for p in pods if p['phase'] == 'Running')
        total_pods = len(pods)
        
        health_percentage = (healthy_deployments / total_deployments * 100) if total_deployments > 0 else 0
        
        response = "**Cluster Health Status:**\n\n"
        response += f"- **Deployments**: {healthy_deployments}/{total_deployments} healthy ({health_percentage:.0f}%)\n"
        response += f"- **Pods**: {healthy_pods}/{total_pods} running\n"
        response += f"- **Overall Status**: {'✓ Healthy' if health_percentage >= 80 else '✗ Needs Attention'}\n"
        
        return response
