"""Main entry point for the Kubernetes Chatbot Agent"""

import argparse
import logging
import sys
import os
from pathlib import Path

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent))

from src.chatbot_agent import K8sChatbotAgent
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

load_dotenv()


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Kubernetes Chatbot Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Interactive mode
  python main.py
  
  # Query mode
  python main.py --query "What version of myapp is running?"
  python main.py --query "When was myapp last deployed?"
  python main.py --query "Show me the cluster health"
        """
    )
    
    parser.add_argument(
        "--query", "-q",
        type=str,
        help="Single query to process (non-interactive mode)"
    )
    parser.add_argument(
        "--namespace", "-n",
        type=str,
        default="default",
        help="Kubernetes namespace to query (default: default)"
    )
    parser.add_argument(
        "--kubeconfig",
        type=str,
        help="Path to kubeconfig file"
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4",
        help="OpenAI model to use (default: gpt-4)"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # Initialize agent
        logger.info("Initializing Kubernetes Chatbot Agent...")
        agent = K8sChatbotAgent(
            kubeconfig_path=args.kubeconfig,
            namespace=args.namespace,
            model=args.model
        )
        logger.info("Agent initialized successfully")
        
        if args.query:
            # Single query mode
            logger.info(f"Processing query: {args.query}")
            response = agent.chat(args.query)
            print("\n" + "="*60)
            print("Response:")
            print("="*60)
            print(response)
            print("="*60)
        else:
            # Interactive mode
            agent.interactive_chat()
    
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
