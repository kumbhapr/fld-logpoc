# Kubernetes Chatbot Agent

A conversational AI agent that queries Kubernetes clusters to answer questions about running applications, deployment versions, and cluster status.

## Features

- **Natural Language Queries**: Ask questions in plain English about your Kubernetes cluster
- **Application Version Queries**: Find out which version of an application is running
- **Deployment Status**: Check the status of deployments and pods
- **Deployment History**: Know when applications were last deployed
- **Cluster Health**: Monitor overall cluster health
- **Log Access**: Retrieve recent logs from application pods
- **Interactive Chat**: Engage in conversational queries or batch process single questions

## Requirements

- Python 3.8+
- Access to a Kubernetes cluster (kubeconfig configured)
- OpenAI API key

## Installation

1. **Clone the repository**
```bash
cd /home/prasadk/prasad/work/k8s-ai
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Configure environment**
```bash
# Copy the example environment file
cp .env.example .env

# Edit .env and add your OpenAI API key
# OPENAI_API_KEY=your_actual_api_key_here
```

4. **Verify Kubernetes access**
```bash
# Ensure your kubeconfig is set up
kubectl cluster-info
```

## Usage

### Interactive Mode

```bash
python main.py
```

This starts an interactive chat session where you can ask multiple questions about your Kubernetes cluster.

Example queries:
```
You: What version of nginx is running?
You: When was the database last deployed?
You: Show me the cluster health status
You: Get logs from the api application
You: List all running applications
```

### Single Query Mode

```bash
python main.py --query "What version of myapp is running?"
python main.py --query "When was the backend service last deployed?"
```

### Advanced Options

```bash
# Specify a different namespace
python main.py -n production

# Use a specific kubeconfig file
python main.py --kubeconfig /path/to/kubeconfig

# Use a different OpenAI model
python main.py --model gpt-3.5-turbo

# Enable verbose logging
python main.py --verbose
```

## Available Queries

The agent can answer questions about:

### Application Information
- "What applications are running in the cluster?"
- "What version of [app-name] is deployed?"
- "Which image is [app-name] using?"

### Deployment Status
- "What is the status of [app-name]?"
- "How many replicas of [app-name] are running?"
- "Are all instances of [app-name] healthy?"

### Deployment History
- "When was [app-name] last deployed?"
- "How long has [app-name] been running?"
- "When was the last update to [app-name]?"

### Logs & Diagnostics
- "Show me the logs from [app-name]"
- "What errors are in [app-name] logs?"

### Cluster Health
- "What is the cluster health?"
- "Are all deployments healthy?"
- "How many pods are running?"

## Architecture

### Components

- **K8sClient** (`src/k8s_client.py`): Direct Kubernetes API client for querying cluster information
- **K8sTools** (`src/tools.py`): High-level tools that format Kubernetes data into human-readable responses
- **ChatbotAgent** (`src/chatbot_agent.py`): LangChain-based agent that interprets natural language queries and routes them to appropriate tools
- **Main** (`main.py`): CLI entry point with interactive and batch query modes

### Data Flow

```
User Query
    ↓
ChatBot Agent (LangChain)
    ↓
Tool Selection & Execution
    ↓
K8s Tools (Formatting Layer)
    ↓
K8s Client (API Layer)
    ↓
Kubernetes Cluster
    ↓
Human-Readable Response
```

## Configuration

### Kubernetes Access

The agent uses the standard kubeconfig file. By default, it looks for:
- `~/.kube/config`
- `KUBECONFIG` environment variable
- In-cluster configuration (if running inside a pod)

To specify a custom kubeconfig:
```bash
python main.py --kubeconfig /path/to/kubeconfig
```

Or set the environment variable:
```bash
export KUBECONFIG=/path/to/kubeconfig
python main.py
```

### OpenAI Configuration

The agent requires an OpenAI API key:

```bash
export OPENAI_API_KEY=your_api_key_here
```

Or add it to `.env`:
```
OPENAI_API_KEY=your_api_key_here
```

## Troubleshooting

### "Could not load kubeconfig" Error
- Ensure your kubeconfig is properly configured
- Run `kubectl cluster-info` to verify connectivity
- Check that the kubeconfig file exists at the specified path

### "OpenAI API key not found" Error
- Set the `OPENAI_API_KEY` environment variable
- Or create a `.env` file with the API key

### No Pods or Deployments Found
- Verify you're querying the correct namespace
- Use `-n` flag to specify a different namespace
- Check that your Kubernetes user has permissions to list resources

### Agent Timeout
- Reduce query complexity
- Check your internet connection
- Verify OpenAI API is accessible

## Development

### Running Tests

```bash
python -m pytest tests/
```

### Code Structure

```
k8s-ai/
├── src/
│   ├── __init__.py
│   ├── k8s_client.py       # Kubernetes API client
│   ├── tools.py            # Tool implementations for agent
│   └── chatbot_agent.py    # LangChain agent
├── tests/                  # Test cases
├── main.py                 # Entry point
├── requirements.txt        # Python dependencies
├── setup.py               # Package setup
└── README.md              # This file
```

## Future Enhancements

- [ ] Support for multiple cluster queries
- [ ] Persistent chat history
- [ ] Custom prompt templates
- [ ] Resource usage statistics
- [ ] Alerting and monitoring integration
- [ ] Cost analysis for deployments
- [ ] Deployment recommendations
- [ ] Multi-language support

## License

MIT

## Contributing

Contributions are welcome! Please feel free to submit pull requests.

## Support

For issues and questions, please create an issue in the repository.
