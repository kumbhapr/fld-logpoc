# Kubernetes Chatbot Agent - Quick Start Guide

## Prerequisites

Before you start, ensure you have:

1. **Python 3.8+** installed
   ```bash
   python --version
   ```

2. **kubectl** configured and connected to your cluster
   ```bash
   kubectl cluster-info
   kubectl get nodes
   ```

3. **OpenAI API Key** from https://platform.openai.com/api-keys

## Setup Steps

### 1. Configure Environment

```bash
# Copy the example environment file
cp .env.example .env

# Edit .env with your settings
nano .env
```

Update the following in `.env`:
```
OPENAI_API_KEY=sk-your-actual-api-key-here
KUBECONFIG=~/.kube/config
K8S_NAMESPACE=default
```

### 2. Install Dependencies

```bash
# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install packages
pip install -r requirements.txt
```

### 3. Verify Setup

```bash
# Check Kubernetes access
kubectl get nodes
kubectl get deployments
kubectl get pods

# Test the agent (this will prompt for an OpenAI API key)
python main.py --query "How many deployments are running?"
```

## Common Use Cases

### Get Running Applications
```bash
python main.py --query "What applications are running?"
```

### Check Application Version
```bash
python main.py --query "What version of nginx is running?"
```

### Check Deployment Status
```bash
python main.py --query "Is the database deployment healthy?"
```

### Check Last Deployment Time
```bash
python main.py --query "When was the API service last deployed?"
```

### Monitor Cluster Health
```bash
python main.py --query "What is the overall cluster health?"
```

### Interactive Mode
```bash
python main.py
```

Then ask multiple questions in succession:
```
You: List all running applications
Agent: [response]
You: What version of app-name is running?
Agent: [response]
You: When was app-name last deployed?
Agent: [response]
```

## Namespace Management

### Query a Specific Namespace
```bash
python main.py -n production --query "What applications are in production?"
python main.py --namespace staging
```

### List Available Namespaces
```bash
kubectl get namespaces
```

## Troubleshooting

### Problem: "Could not load kubeconfig"
**Solution:**
```bash
# Explicitly set kubeconfig path
export KUBECONFIG=~/.kube/config
python main.py

# Or use command line
python main.py --kubeconfig ~/.kube/config
```

### Problem: "OpenAI API key not found"
**Solution:**
```bash
# Set environment variable directly
export OPENAI_API_KEY=sk-your-api-key-here
python main.py

# Or update .env file
nano .env  # Add your API key
```

### Problem: "Access denied" or permission errors
**Solution:**
```bash
# Check your user permissions
kubectl auth can-i list deployments
kubectl auth can-i list pods
kubectl auth can-i get pods

# If denied, contact your cluster administrator
```

### Problem: Agent returns "No deployments found"
**Solutions:**
1. Verify you're querying the correct namespace:
   ```bash
   python main.py -n your-namespace --query "Show applications"
   ```

2. Check that deployments exist:
   ```bash
   kubectl get deployments -n your-namespace
   ```

## Advanced Configuration

### Using Different OpenAI Models
```bash
# Use GPT-3.5 (faster, cheaper)
python main.py --model gpt-3.5-turbo

# Use GPT-4 (more capable, default)
python main.py --model gpt-4

# Use Claude via other configuration (requires setup)
```

### Enable Verbose Logging
```bash
python main.py --verbose
```

This will show:
- All API calls
- LangChain agent reasoning
- Kubernetes queries
- Response processing

### Using Custom Kubeconfig
```bash
python main.py --kubeconfig /path/to/custom/kubeconfig
```

## Environment Variables

Full list of environment variables:

```bash
# Required
OPENAI_API_KEY=sk-...          # Your OpenAI API key

# Optional - Kubernetes
KUBECONFIG=~/.kube/config      # Path to kubeconfig file
K8S_NAMESPACE=default           # Default namespace

# Optional - Logging
LOG_LEVEL=INFO                  # DEBUG, INFO, WARNING, ERROR
```

## Running Tests

```bash
# Run all tests
python -m pytest tests/

# Run specific test file
python -m pytest tests/test_k8s_client.py

# Run with verbose output
python -m pytest tests/ -v

# Run with coverage
python -m pytest tests/ --cov=src
```

## Next Steps

1. Start with interactive mode to explore your cluster
2. Use query mode for automation/scripting
3. Integrate with CI/CD pipelines
4. Build dashboards or alerts based on queries

## Support

For issues:
1. Check the main README.md
2. Enable verbose logging: `--verbose`
3. Check logs for error messages
4. Verify Kubernetes and OpenAI connectivity

## Performance Tips

- Use specific namespace queries to reduce API calls
- Query types that need logs will take longer
- Cache frequent queries if needed
- Batch multiple queries in interactive mode
