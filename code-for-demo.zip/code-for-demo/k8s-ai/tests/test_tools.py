"""Tests for K8s tools"""

import unittest
from unittest.mock import Mock, patch
from src.tools import K8sTools


class TestK8sTools(unittest.TestCase):
    """Test cases for K8sTools"""

    def setUp(self):
        """Set up test fixtures"""
        self.mock_k8s_client = Mock()
        self.tools = K8sTools(self.mock_k8s_client)

    def test_get_app_version(self):
        """Test getting application version"""
        self.mock_k8s_client.get_deployments.return_value = [
            {
                'name': 'myapp',
                'image': 'myapp:v2.1.0',
                'ready_replicas': 3,
                'replicas': 3,
            }
        ]
        
        result = self.tools.get_app_version('myapp')
        
        self.assertIn('v2.1.0', result)
        self.assertIn('myapp', result)

    def test_get_deployment_status(self):
        """Test getting deployment status"""
        self.mock_k8s_client.search_pod_by_app.return_value = []
        self.mock_k8s_client.get_deployments.return_value = [
            {
                'name': 'myapp',
                'replicas': 3,
                'ready_replicas': 3,
                'updated_replicas': 3,
                'available_replicas': 3,
            }
        ]
        
        result = self.tools.get_deployment_status('myapp')
        
        self.assertIn('Healthy', result)
        self.assertIn('3/3', result)

    def test_get_cluster_health(self):
        """Test cluster health status"""
        self.mock_k8s_client.get_deployments.return_value = [
            {'ready_replicas': 3, 'replicas': 3},
            {'ready_replicas': 2, 'replicas': 3},
        ]
        self.mock_k8s_client.get_pods.return_value = [
            {'phase': 'Running'},
            {'phase': 'Running'},
            {'phase': 'Pending'},
        ]
        
        result = self.tools.get_cluster_health()
        
        self.assertIn('50%', result)
        self.assertIn('2/3', result)


if __name__ == '__main__':
    unittest.main()
