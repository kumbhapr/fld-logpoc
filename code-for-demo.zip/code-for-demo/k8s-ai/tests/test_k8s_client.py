"""Tests for K8s client"""

import unittest
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime, timezone
from src.k8s_client import KubernetesClient


class TestKubernetesClient(unittest.TestCase):
    """Test cases for KubernetesClient"""

    @patch('src.k8s_client.config.load_kube_config')
    @patch('src.k8s_client.client.CoreV1Api')
    @patch('src.k8s_client.client.AppsV1Api')
    def setUp(self, mock_apps_api, mock_core_api, mock_load_config):
        """Set up test fixtures"""
        self.mock_core_api = mock_core_api.return_value
        self.mock_apps_api = mock_apps_api.return_value
        mock_load_config.return_value = None
        
        self.client = KubernetesClient()
        self.client.v1 = self.mock_core_api
        self.client.apps_v1 = self.mock_apps_api

    def test_get_pods_success(self):
        """Test successful pod retrieval"""
        # Create mock pod
        mock_pod = MagicMock()
        mock_pod.metadata.name = "test-pod"
        mock_pod.metadata.namespace = "default"
        mock_pod.metadata.creation_timestamp = datetime.now(timezone.utc)
        mock_pod.status.phase = "Running"
        mock_pod.spec.containers = [MagicMock(name="test-container", image="test:latest")]
        mock_pod.status.container_statuses = [
            MagicMock(name="test-container", ready=True)
        ]
        
        # Mock API response
        mock_pod_list = MagicMock()
        mock_pod_list.items = [mock_pod]
        self.mock_core_api.list_namespaced_pod.return_value = mock_pod_list
        
        # Call function
        pods = self.client.get_pods()
        
        # Assertions
        self.assertEqual(len(pods), 1)
        self.assertEqual(pods[0]['name'], "test-pod")
        self.assertEqual(pods[0]['phase'], "Running")

    def test_get_deployments_success(self):
        """Test successful deployment retrieval"""
        # Create mock deployment
        mock_deploy = MagicMock()
        mock_deploy.metadata.name = "test-deploy"
        mock_deploy.metadata.namespace = "default"
        mock_deploy.metadata.creation_timestamp = datetime.now(timezone.utc)
        mock_deploy.spec.replicas = 3
        mock_deploy.status.ready_replicas = 3
        mock_deploy.status.updated_replicas = 3
        mock_deploy.status.available_replicas = 3
        mock_deploy.spec.template.spec.containers = [
            MagicMock(image="test:v1.0.0")
        ]
        
        # Mock API response
        mock_deploy_list = MagicMock()
        mock_deploy_list.items = [mock_deploy]
        self.mock_apps_api.list_namespaced_deployment.return_value = mock_deploy_list
        
        # Call function
        deployments = self.client.get_deployments()
        
        # Assertions
        self.assertEqual(len(deployments), 1)
        self.assertEqual(deployments[0]['name'], "test-deploy")
        self.assertEqual(deployments[0]['replicas'], 3)


if __name__ == '__main__':
    unittest.main()
