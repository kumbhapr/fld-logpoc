# K8s-AI Chatbot Agent - Development Guidelines

## Project Overview
This is a Kubernetes chatbot agent that uses LangChain and OpenAI to answer natural language questions about Kubernetes clusters. It queries pod information, deployment versions, and status.

## Architecture

### Core Components
- **K8sClient** (src/k8s_client.py): Direct Kubernetes API interactions
- **K8sTools** (src/tools.py): Tool implementations that format Kubernetes data
- **ChatbotAgent** (src/chatbot_agent.py): LangChain agent orchestration
- **Config** (src/config.py): Configuration management
- **Main** (main.py): CLI entry point

### Key Features
1. Query application versions running in Kubernetes
2. Check deployment status and pod information
3. Retrieve deployment timestamps
4. View cluster health statistics
5. Access pod logs
6. Interactive and batch query modes

## Development Guidelines

### When Adding New Queries/Tools
1. Add method to K8sClient for raw Kubernetes data
2. Add tool method in K8sTools for formatted response
3. Register tool in K8sChatbotAgent._create_tools()
4. Add tests in tests/ directory
5. Update README with example queries

### Code Style
- Use type hints for all functions
- Add docstrings to all classes and methods
- Follow PEP 8 naming conventions
- Use logging instead of print statements
- Add try-except for API calls

### Testing
- Write unit tests for new functionality
- Mock Kubernetes API responses
- Test both success and error cases
- Run: `python -m pytest tests/`

### Dependencies
- langchain & langchain-openai: LLM agent framework
- kubernetes: K8s API client
- python-dotenv: Environment configuration
- pytest: Testing framework

## Common Tasks

### Adding a New Query Type
1. Add K8s query method in src/k8s_client.py
2. Add formatter method in src/tools.py
3. Create Tool in _create_tools()
4. Test in main.py

### Debugging
- Use `--verbose` flag for detailed logging
- Check agent_scratchpad in agent responses
- Use mock K8s client for testing

### Configuration
- Add to .env for environment variables
- Update src/config.py for new config options
- Document in QUICKSTART.md

## Performance Considerations
- Batch queries in interactive mode
- Use specific namespace filters
- Minimize large log retrievals
- Cache frequent queries if needed

## Future Enhancements
- Multi-cluster support
- Persistent chat history
- Resource usage analytics
- Deployment recommendations
- Integration with monitoring systems
