# Security Remediation Checklist

**Last Updated:** 2026-01-28

---

## CRITICAL ISSUES - Action Required Immediately

### 1. Update Vulnerable Dependencies

**Status:** ⛔ NOT STARTED  
**Effort:** 2 hours  
**Risk:** CRITICAL

```bash
# Step 1: Update pom.xml
cat > /tmp/pom_updates.txt << 'EOF'
OLD:
  <version>2.5.1.RELEASE</version>  (spring-security-oauth2)
  <version>9.25.6</version>  (nimbus-jose-jwt)
  <version>2.13.4</version>  (jackson-databind)

NEW:
  <version>2.5.2.RELEASE</version>  (spring-security-oauth2)
  <version>9.37.3</version>  (nimbus-jose-jwt)
  <version>2.14.2</version>  (jackson-databind)
EOF

# Step 2: Apply changes
# Edit: /home/prasadk/prasad/work/mitrd-next/oidc-lightweight-server-lib/pom.xml

# Step 3: Verify build
mvn clean compile
```

**Files to Update:**
- [ ] `oidc-lightweight-server-lib/pom.xml` - Line 55 (spring-security-oauth2)
- [ ] `oidc-lightweight-server-lib/pom.xml` - Line 64 (nimbus-jose-jwt)
- [ ] `oidc-lightweight-server-lib/pom.xml` - Line 67 (jackson-databind)

---

### 2. Implement HTTPS/TLS

**Status:** ⛔ NOT STARTED  
**Effort:** 4 hours  
**Risk:** CRITICAL

**Steps:**

1. Generate SSL certificate (development):
```bash
keytool -genkeypair \
  -alias oidc-server \
  -keyalg RSA \
  -keysize 2048 \
  -keystore keystore.p12 \
  -storetype PKCS12 \
  -storepass changeit \
  -validity 365 \
  -dname "CN=localhost,OU=Dev,O=Example,L=City,ST=State,C=US"
```

2. Add to `application.yml`:
```yaml
server:
  port: 8443
  ssl:
    key-store: classpath:keystore.p12
    key-store-password: changeit
    key-store-type: PKCS12
    key-alias: oidc-server
  servlet:
    context-path: /idp
```

3. Enable HTTPS in SecurityConfiguration:
- [ ] Update `sample-oidc-idp/src/main/java/com/example/idp/config/SecurityConfiguration.java`
  - Add `requiresSecure()` to HttpSecurity
  - Configure HSTS header

4. Update issuer URL resolution:
- [ ] Modify `OIDCEndpointController.java` to use HTTPS scheme

**Files to Update:**
- [ ] `sample-oidc-idp/src/main/resources/application.yml`
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/config/SecurityConfiguration.java`
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/controller/OIDCEndpointController.java`

---

### 3. Encrypt Client Secrets

**Status:** ⛔ NOT STARTED  
**Effort:** 6 hours  
**Risk:** CRITICAL

**Implementation Steps:**

1. Create SecretEncryptionService:
```
File: oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/security/SecretEncryptionService.java
```

2. Update token endpoint to use encrypted comparison:
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/controller/OIDCEndpointController.java`
  - Line ~145: Replace plaintext comparison with encrypted secret handling

3. Migration script for existing secrets:
- [ ] Create migration script to encrypt existing client secrets

4. Configuration:
- [ ] Add encryption key to `application.yml` or environment variables

**Files to Create:**
- [ ] `oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/security/SecretEncryptionService.java` (NEW)

**Files to Update:**
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/controller/OIDCEndpointController.java`
- [ ] `sample-oidc-idp/src/main/resources/application.yml`

---

### 4. Fix Timing Attack in Credential Comparison

**Status:** ⛔ NOT STARTED  
**Effort:** 1 hour  
**Risk:** CRITICAL

**Quick Fix:**
```java
// Location: OIDCEndpointController.java, Line ~145
// Replace:
if (!clientOpt.get().getClientSecret().equals(clientSecret)) {

// With:
if (!MessageDigest.isEqual(
        clientSecret.getBytes(StandardCharsets.UTF_8),
        client.getClientSecret().getBytes(StandardCharsets.UTF_8))) {
```

**Files to Update:**
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/controller/OIDCEndpointController.java` (Line ~145)

---

## HIGH PRIORITY ISSUES - Fix Within 2 Weeks

### 5. Implement Rate Limiting

**Status:** ⛔ NOT STARTED  
**Effort:** 8 hours  
**Risk:** HIGH

**Implementation:**

1. Add dependency to `pom.xml`:
```xml
<dependency>
    <groupId>io.github.bucket4j</groupId>
    <artifactId>bucket4j-core</artifactId>
    <version>7.6.0</version>
</dependency>
```

2. Create RateLimiterService:
```
File: sample-oidc-idp/src/main/java/com/example/idp/service/RateLimiterService.java
```

3. Add rate limiting to endpoints:
- [ ] `/authorize` - 100 requests per minute per client
- [ ] `/token` - 50 requests per minute per client  
- [ ] `/userinfo` - 100 requests per minute per token
- [ ] `/authorize/approve` - 20 requests per minute per user

4. Configuration:
```yaml
rate-limiting:
  enabled: true
  authorize:
    requests-per-minute: 100
  token:
    requests-per-minute: 50
  userinfo:
    requests-per-minute: 100
```

**Files to Create:**
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/service/RateLimiterService.java` (NEW)

**Files to Update:**
- [ ] `oidc-lightweight-server-lib/pom.xml`
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/controller/OIDCEndpointController.java`
- [ ] `sample-oidc-idp/src/main/resources/application.yml`

---

### 6. Implement PKCE (RFC 7636)

**Status:** ⛔ NOT STARTED  
**Effort:** 10 hours  
**Risk:** HIGH

**Implementation:**

1. Update AuthorizationCode model:
```
File: oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/model/AuthorizationCode.java
- Already has codeChallenge and codeChallengeMethod fields
```

2. Update AuthorizationCodeService interface:
- [ ] Add parameters: codeChallenge, codeChallengeMethod

3. Update AuthorizationCodeServiceImpl:
- [ ] Store PKCE parameters in createAuthorizationCode()

4. Update OIDCEndpointController:
- [ ] /authorize endpoint: Accept code_challenge and code_challenge_method
- [ ] /authorize/approve endpoint: Pass PKCE parameters to service
- [ ] /token endpoint: Validate code_verifier against code_challenge

5. Create PKCE validation utility:
```
File: oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/util/PKCEValidator.java
```

**Files to Update:**
- [ ] `oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/service/AuthorizationCodeService.java`
- [ ] `oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/service/impl/AuthorizationCodeServiceImpl.java`
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/controller/OIDCEndpointController.java`

**Files to Create:**
- [ ] `oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/util/PKCEValidator.java` (NEW)

---

### 7. Fix CSRF Vulnerability in Forms

**Status:** ⛔ NOT STARTED  
**Effort:** 2 hours  
**Risk:** HIGH

**Quick Fix:**

1. Add CSRF token to authorize-consent.html form:
```html
<!-- Location: sample-oidc-idp/src/main/resources/templates/authorize-consent.html -->
<!-- Add this line inside the <form> -->
<input type="hidden" th:name="${_csrf.parameterName}" th:value="${_csrf.token}" />
```

2. Verify CSRF is enabled in SecurityConfiguration:
```java
@Bean
public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http
        .csrf()
        .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
        .and()
        // ...
}
```

**Files to Update:**
- [ ] `sample-oidc-idp/src/main/resources/templates/authorize-consent.html` (Line ~120)
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/config/SecurityConfiguration.java`

---

### 8. Improve Input Validation

**Status:** ⛔ NOT STARTED  
**Effort:** 8 hours  
**Risk:** HIGH

**Validation Methods to Implement:**

1. Validate scope parameter:
```java
Set<String> requestedScopes = parseScopes(scope);
if (!validateScopes(client, requestedScopes)) {
    return "error/invalid-scope";
}
```

2. Validate response_type:
```java
if (!client.getResponseTypes().contains(responseType)) {
    return "error/unsupported_response_type";
}
```

3. Validate nonce (optional but include):
```java
if (nonce != null && !isValidNonce(nonce)) {
    return "error/invalid_request";
}
```

4. Create validation utility class:
```
File: oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/util/OIDCValidator.java
```

**Files to Create:**
- [ ] `oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/util/OIDCValidator.java` (NEW)

**Files to Update:**
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/controller/OIDCEndpointController.java`

---

## MEDIUM PRIORITY ISSUES - Fix Within 4 Weeks

### 9. Implement CORS Configuration

**Status:** ⛔ NOT STARTED  
**Effort:** 3 hours  
**Risk:** MEDIUM

**Steps:**

1. Create CorsConfiguration class:
```
File: sample-oidc-idp/src/main/java/com/example/idp/config/CorsConfiguration.java
```

2. Configure allowed origins in application.yml:
```yaml
cors:
  allowed-origins: 
    - http://localhost:3000
    - https://trusted-app.com
  allowed-methods: GET,POST
  max-age: 3600
```

**Files to Create:**
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/config/CorsConfiguration.java` (NEW)

**Files to Update:**
- [ ] `sample-oidc-idp/src/main/resources/application.yml`

---

### 10. Add Security Headers

**Status:** ⛔ NOT STARTED  
**Effort:** 3 hours  
**Risk:** MEDIUM

**Implementation:**

1. Update SecurityConfiguration:
```java
.headers()
    .httpStrictTransportSecurityResolver(...)  // HSTS
    .frameOptions().deny()  // X-Frame-Options
    .contentTypeOptions()  // X-Content-Type-Options
    .xssProtection()  // X-XSS-Protection
    .contentSecurityPolicy()  // CSP
    .referrerPolicy()  // Referrer-Policy
```

2. Update application.yml:
```yaml
server:
  servlet:
    session:
      cookie:
        http-only: true
        secure: true
        same-site: strict
```

**Files to Update:**
- [ ] `sample-oidc-idp/src/main/java/com/example/idp/config/SecurityConfiguration.java`
- [ ] `sample-oidc-idp/src/main/resources/application.yml`

---

### 11. Improve Secret Storage

**Status:** ⛔ NOT STARTED (Depends on #3)  
**Effort:** 5 hours  
**Risk:** MEDIUM

**Steps:**

1. Remove plaintext secrets from logs
2. Add encryption at rest for all sensitive fields
3. Implement secret rotation mechanism
4. Add audit logging for secret access

**Files to Update:**
- [ ] ClientDetailsServiceImpl.java
- [ ] All logging statements

---

### 12. Fix Authorization Code Generation

**Status:** ⛔ NOT STARTED  
**Effort:** 2 hours  
**Risk:** MEDIUM

**Quick Fix:**
```java
// Location: AuthorizationCodeServiceImpl.java, Line ~70
// Replace:
private String generateAuthorizationCode() {
    return DigestUtils.sha256Hex(UUID.randomUUID().toString()).substring(0, 32);
}

// With:
private String generateAuthorizationCode() {
    byte[] randomBytes = new byte[32];  // 256 bits
    new SecureRandom().nextBytes(randomBytes);
    return Base64.getUrlEncoder()
        .withoutPadding()
        .encodeToString(randomBytes);
}
```

**Files to Update:**
- [ ] `oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/service/impl/AuthorizationCodeServiceImpl.java` (Line ~70)

---

## LOW PRIORITY ISSUES - Nice to Have

### 13. Remove Secrets from Logs

**Status:** ⛔ NOT STARTED  
**Effort:** 2 hours  
**Risk:** LOW

**Implementation:**

1. Update @ToString annotations:
```java
@ToString(exclude = {"clientSecret", "privateKey"})
```

2. Update logging calls:
```java
log.info("Client registered: {}", client.getClientId());  // NOT client object
```

**Files to Update:**
- [ ] `oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/model/ClientDetails.java`
- [ ] All service implementation classes

---

### 14. Reduce Token Expiration Times

**Status:** ⛔ NOT STARTED  
**Effort:** 1 hour  
**Risk:** LOW

**Change:**
```yaml
oidc:
  token:
    id-token-validity-seconds: 600        # Keep as is
    access-token-validity-seconds: 900    # Change from 3600 to 900 (15 minutes)
    authorization-code-validity-seconds: 300   # Keep as is
```

**Files to Update:**
- [ ] `sample-oidc-idp/src/main/resources/application.yml`

---

### 15. Enhance Error Handling

**Status:** ⛔ NOT STARTED  
**Effort:** 3 hours  
**Risk:** LOW

**Implementation:**

1. Create custom exceptions
2. Improve error messages
3. Add proper exception handling

**Files to Create:**
- [ ] `oidc-lightweight-server-lib/src/main/java/com/example/oidc/lib/exception/` (package)

---

## Verification Checklist

After implementing each fix:

- [ ] Code compiles without errors
- [ ] All existing tests pass
- [ ] New security tests added
- [ ] Security audit tool runs successfully
- [ ] OWASP ZAP scan shows no critical issues
- [ ] Code review completed
- [ ] Documented in CHANGELOG

---

## Testing Commands

```bash
# Compile and build
mvn clean compile
mvn clean install

# Run tests
mvn test

# Run with security scanning
mvn dependency:check
mvn org.owasp:dependency-check-maven:check

# Manual HTTPS test
curl -k https://localhost:8443/idp/.well-known/openid-configuration

# Rate limiting test
for i in {1..51}; do
  curl -X POST http://localhost:8080/idp/token \
    -d "client_id=test&client_secret=test" &
done

# CSRF test
curl -X POST http://localhost:8080/idp/authorize/approve \
  -H "Origin: http://attacker.com" \
  -d "client_id=test"
```

---

## Progress Tracking

| Phase | Status | Completion % | Target Date |
|-------|--------|-------------|-------------|
| Phase 1 (Critical) | ⛔ NOT STARTED | 0% | 2026-02-04 |
| Phase 2 (High) | ⛔ NOT STARTED | 0% | 2026-02-28 |
| Phase 3 (Medium) | ⛔ NOT STARTED | 0% | 2026-03-31 |
| Phase 4 (Low) | ⛔ NOT STARTED | 0% | 2026-04-30 |

---

## Sign-Off

- [ ] Security audit completed
- [ ] Remediation plan approved
- [ ] Team trained on security issues
- [ ] Monitoring and alerting configured
- [ ] Production deployment ready

---

**Audit Date:** 2026-01-28  
**Next Review:** 2026-03-28  
**Approval:** _________________
