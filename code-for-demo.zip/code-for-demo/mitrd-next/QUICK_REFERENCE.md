# Quick Reference Card

## 🚀 Getting Started (5 minutes)

### 1. Start MongoDB
```bash
mongod  # or: docker run -d -p 27017:27017 mongo
```

### 2. Build the Library
```bash
cd oidc-lightweight-server-lib
mvn clean install
```

### 3. Run the Sample IDP
```bash
cd sample-oidc-idp
mvn spring-boot:run
```

### 4. Access the IDP
```
http://localhost:8080/idp
```

---

## 📚 Key Documentation

| Document | Purpose | Read Time |
|----------|---------|-----------|
| `README.md` | Complete guide | 15 min |
| `QUICKSTART.md` | Get running | 10 min |
| `ARCHITECTURE.md` | System design | 20 min |
| `PRODUCTION_DEPLOYMENT.md` | Deploy to production | 30 min |
| `PROJECT_SUMMARY.md` | Overview | 5 min |

---

## 🏗️ Project Structure

```
LIBRARY                         SAMPLE IDP
├── model/                       ├── controller/
│   ├── ClientDetails            │   ├── OIDCEndpointController
│   ├── AccessToken              │   └── HomeController
│   ├── AuthorizationCode        ├── config/
│   ├── RefreshToken             │   └── SecurityConfiguration
│   └── UserInfo                 └── templates/
├── repository/                      ├── home.html
│   ├── ClientDetailsRepository      ├── login.html
│   ├── AccessTokenRepository        ├── authorize-consent.html
│   └── ...                          └── error/
├── service/
│   ├── ClientDetailsService
│   ├── AccessTokenService
│   ├── AuthorizationCodeService
│   ├── JWTTokenService
│   └── UserInfoService
└── service/impl/
    └── (implementations)
```

---

## 🔌 Core Services (Library API)

### ClientDetailsService
```java
// Register a new client
ClientDetails client = new ClientDetails();
clientDetailsService.registerClient(client);

// Get client by ID
Optional<ClientDetails> client = 
    clientDetailsService.getClientByClientId("client-id");

// Update client
clientDetailsService.updateClient(client);

// Delete client
clientDetailsService.deleteClient("client-id");
```

### JWTTokenService
```java
// Create ID token
JWT idToken = jwtTokenService.createIdToken(
    clientId, userId, issuer, audience, claims
);

// Validate token
if (jwtTokenService.validateToken(tokenValue)) {
    // Token is valid
}

// Parse token
JWT jwt = jwtTokenService.parseToken(tokenValue);
```

### AuthorizationCodeService
```java
// Create authorization code
AuthorizationCode code = authorizationCodeService
    .createAuthorizationCode(clientId, userId, redirectUri, scopes);

// Get authorization code
Optional<AuthorizationCode> code = 
    authorizationCodeService.getAuthorizationCode("code");

// Consume authorization code
authorizationCodeService.consumeAuthorizationCode("code");
```

### AccessTokenService
```java
// Create access token
AccessToken token = accessTokenService
    .createAccessToken(clientId, userId, scopes);

// Get access token
Optional<AccessToken> token = 
    accessTokenService.getAccessToken("token-value");

// Revoke access token
accessTokenService.revokeAccessToken("token-value");
```

### UserInfoService
```java
// Save user info
UserInfo userInfo = new UserInfo();
userInfoService.saveUserInfo(userInfo);

// Get user info
Optional<UserInfo> info = userInfoService.getUserInfo("user-id");

// Update user info
userInfoService.updateUserInfo(userInfo);
```

---

## 🔗 OIDC Endpoints (Sample IDP)

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/authorize` | GET | Authorization endpoint |
| `/token` | POST | Token endpoint |
| `/userinfo` | GET | User information endpoint |
| `/.well-known/openid-configuration` | GET | Discovery endpoint |
| `/authorize/approve` | POST | Consent approval |

---

## 📋 Demo Accounts

```
user1 / password1     (USER role)
user2 / password2     (USER, ADMIN roles)
admin / adminpass     (ADMIN role)
```

---

## 🗄️ MongoDB Collections

```javascript
// Client registrations
db.clients

// Authorization codes (auto-expires after 5 minutes)
db.authorization_codes

// Access tokens (auto-expires after 1 hour)
db.access_tokens

// Refresh tokens (auto-expires after 30 days)
db.refresh_tokens

// User information
db.user_info
```

---

## ⚙️ Configuration Keys

### Token Lifetimes
```yaml
oidc:
  token:
    id-token-validity-seconds: 600              # 10 minutes
    access-token-validity-seconds: 3600         # 1 hour
    authorization-code-validity-seconds: 300    # 5 minutes
```

### Server Configuration
```yaml
server:
  port: 8080
  servlet:
    context-path: /idp

spring:
  data:
    mongodb:
      uri: mongodb://localhost:27017/sample-idp
```

---

## 🧪 Testing

### Run all tests
```bash
mvn test
```

### Run specific test
```bash
mvn test -Dtest=ClientDetailsServiceImplTest
```

### Run with coverage
```bash
mvn clean test jacoco:report
```

---

## 🐳 Docker & Kubernetes

### Build Docker image
```bash
docker build -t oidc-idp:1.0.0 sample-oidc-idp/
```

### Run Docker container
```bash
docker run -p 8080:8080 \
  -e MONGODB_URI=mongodb://mongo:27017/idp \
  oidc-idp:1.0.0
```

### Deploy to Kubernetes
```bash
kubectl apply -f deployment.yaml
```

---

## 🔒 Security Checklist

- [ ] Use HTTPS/TLS in production
- [ ] Store client secrets securely
- [ ] Set appropriate token lifetimes
- [ ] Validate redirect URIs
- [ ] Use strong passwords
- [ ] Enable rate limiting
- [ ] Configure CORS properly
- [ ] Set secure cookies (HttpOnly, Secure, SameSite)
- [ ] Implement audit logging
- [ ] Regular security updates

---

## 📊 Common cURL Commands

### Login and get authorization code
```bash
curl -G "http://localhost:8080/idp/authorize" \
  --data-urlencode "client_id=test-app" \
  --data-urlencode "response_type=code" \
  --data-urlencode "redirect_uri=http://localhost:3000/callback" \
  --data-urlencode "scope=openid profile email"
```

### Exchange code for tokens
```bash
curl -X POST "http://localhost:8080/idp/token" \
  -d "grant_type=authorization_code" \
  -d "code=CODE_FROM_PREVIOUS_STEP" \
  -d "client_id=test-app" \
  -d "client_secret=test-secret" \
  -d "redirect_uri=http://localhost:3000/callback"
```

### Get user information
```bash
curl -H "Authorization: Bearer ACCESS_TOKEN" \
  http://localhost:8080/idp/userinfo
```

### Get OpenID configuration
```bash
curl http://localhost:8080/idp/.well-known/openid-configuration | jq
```

---

## 🐛 Troubleshooting

### MongoDB connection failed
```
Error: connect ECONNREFUSED 127.0.0.1:27017
Solution: Start MongoDB (mongod or docker run mongo)
```

### Port already in use
```
Error: Address already in use
Solution: Change port in application.yml or kill process on port
```

### Cannot login
```
Error: Login failed
Check: Use correct credentials (user1/password1) - case sensitive
```

### Authorization code expired
```
Error: invalid_code
Check: Codes expire after 5 minutes, start fresh flow
```

---

## 📱 API Response Examples

### Token Endpoint Response
```json
{
  "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
  "id_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "Bearer",
  "expires_in": 3600
}
```

### UserInfo Endpoint Response
```json
{
  "sub": "user1",
  "email": "user1@example.com",
  "email_verified": true,
  "name": "Sample User",
  "given_name": "Sample",
  "family_name": "User",
  "locale": "en_US"
}
```

### OpenID Configuration Response
```json
{
  "issuer": "http://localhost:8080/idp",
  "authorization_endpoint": "http://localhost:8080/idp/authorize",
  "token_endpoint": "http://localhost:8080/idp/token",
  "userinfo_endpoint": "http://localhost:8080/idp/userinfo",
  "jwks_uri": "http://localhost:8080/idp/.well-known/jwks.json",
  "response_types_supported": ["code", "id_token", "token id_token"],
  "grant_types_supported": ["authorization_code", "implicit", "refresh_token"],
  ...
}
```

---

## 🚢 Deployment Steps

1. **Build**: `mvn clean package`
2. **Docker**: `docker build -t oidc-idp:1.0.0 .`
3. **Push**: `docker push registry/oidc-idp:1.0.0`
4. **Deploy**: `kubectl apply -f deployment.yaml`
5. **Verify**: `kubectl get pods -n production`

---

## 📖 Learning Resources

- [OpenID Connect Core 1.0](https://openid.net/specs/openid-connect-core-1_0.html)
- [OAuth 2.0 RFC 6749](https://tools.ietf.org/html/rfc6749)
- [JWT RFC 7519](https://tools.ietf.org/html/rfc7519)
- [Spring Security Documentation](https://spring.io/projects/spring-security)
- [MongoDB Documentation](https://docs.mongodb.com)

---

## ✅ Completion Checklist

- [x] Lightweight OIDC library created
- [x] MongoDB integration completed
- [x] Sample IDP built
- [x] Security configured
- [x] Tests written
- [x] Documentation complete
- [x] Production deployment guide ready
- [x] Ready for use in other IDPs

---

**Status**: ✅ Complete and Production-Ready  
**Version**: 1.0.0  
**Last Updated**: January 28, 2024
