# Quick Start Guide

This guide will help you get up and running with the OIDC Lightweight Server Library and Sample IDP in 10 minutes.

## Prerequisites Check

Verify you have the required tools:

```bash
java -version          # Should be Java 11+
mvn -version           # Should be Maven 3.6+
mongod --version       # Should be MongoDB 4.0+
```

## Step 1: Start MongoDB

### Option A: MongoDB Installed Locally

```bash
# macOS with Homebrew
brew services start mongodb-community

# Ubuntu/Debian with systemctl
sudo systemctl start mongodb

# Or just run mongod
mongod --dbpath /data/db
```

### Option B: MongoDB with Docker

```bash
docker run -d -p 27017:27017 --name oidc-mongodb mongo:latest
```

## Step 2: Build and Install the Library

```bash
cd /home/prasadk/prasad/work/mitrd-next/oidc-lightweight-server-lib

# Build and install to local Maven repository
mvn clean install -DskipTests

# Should see "BUILD SUCCESS"
```

## Step 3: Start the Sample IDP

```bash
cd /home/prasadk/prasad/work/mitrd-next/sample-oidc-idp

# Run the application
mvn spring-boot:run
```

You should see output like:
```
2024-01-28 10:00:00 INFO  - Started SampleIdpApplication in 5.234 seconds
```

The IDP is now running at: `http://localhost:8080/idp`

## Step 4: Access the IDP Home Page

Open your browser and navigate to:
```
http://localhost:8080/idp
```

You should see the Sample OIDC IDP home page.

## Step 5: Test the OAuth 2.0 Flow

### 5.1 Create a Test Client

Using MongoDB client (mongosh):

```bash
mongosh mongodb://localhost:27017/sample-idp
```

Insert a test client:

```javascript
db.clients.insertOne({
  clientId: "test-app",
  clientSecret: "test-secret",
  clientName: "Test Application",
  redirectUris: ["http://localhost:3000/callback", "http://localhost:5000/callback"],
  allowedGrantTypes: ["authorization_code", "refresh_token"],
  responseTypes: ["code"],
  scopes: ["openid", "profile", "email"],
  applicationType: "web",
  subjectType: "public",
  tokenEndpointAuthMethod: "client_secret_basic",
  accessTokenValiditySeconds: 3600,
  refreshTokenValiditySeconds: 86400,
  idTokenValiditySeconds: 600,
  createdAt: new Date(),
  updatedAt: new Date()
})
```

### 5.2 Initiate Authorization Request

Navigate to (or use curl):

```bash
curl -G "http://localhost:8080/idp/authorize" \
  --data-urlencode "client_id=test-app" \
  --data-urlencode "response_type=code" \
  --data-urlencode "redirect_uri=http://localhost:3000/callback" \
  --data-urlencode "scope=openid profile email" \
  --data-urlencode "state=xyz123" \
  --data-urlencode "nonce=abc456"
```

Or visit directly in browser:
```
http://localhost:8080/idp/authorize?client_id=test-app&response_type=code&redirect_uri=http://localhost:3000/callback&scope=openid+profile+email&state=xyz123&nonce=abc456
```

### 5.3 Login and Authorize

1. You'll be redirected to login page
2. Use demo credentials: `user1` / `password1`
3. Click "Authorize" on the consent screen
4. You'll receive an authorization code in the redirect URL

### 5.4 Exchange Code for Token

```bash
curl -X POST "http://localhost:8080/idp/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=authorization_code" \
  -d "code=YOUR_AUTH_CODE_HERE" \
  -d "client_id=test-app" \
  -d "client_secret=test-secret" \
  -d "redirect_uri=http://localhost:3000/callback"
```

You'll receive a JSON response with:
- `access_token` - JWT token for API access
- `id_token` - JWT token with user info
- `token_type` - "Bearer"
- `expires_in` - 3600 (1 hour)

### 5.5 Get User Information

Use the access token from step 5.4:

```bash
curl -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE" \
  http://localhost:8080/idp/userinfo
```

You should get a JSON response:
```json
{
  "sub": "user1",
  "email": "user1@example.com",
  "email_verified": true,
  "name": "Sample User",
  "given_name": "Sample",
  "family_name": "User",
  "locale": "en_US"
}
```

## Step 6: Verify Configuration Endpoint

Check the OpenID Configuration:

```bash
curl http://localhost:8080/idp/.well-known/openid-configuration | jq
```

You should see all supported endpoints and algorithms.

## Demo Accounts

Use these accounts for testing:

| Username | Password | Notes |
|----------|----------|-------|
| user1 | password1 | Regular user |
| user2 | password2 | User + Admin |
| admin | adminpass | Admin only |

## Troubleshooting

### Issue: MongoDB Connection Failed

```
Error: connect ECONNREFUSED 127.0.0.1:27017
```

**Solution:** Ensure MongoDB is running
```bash
# Check if MongoDB is running
ps aux | grep mongod

# Start MongoDB if not running
mongod --dbpath /data/db
```

### Issue: Port Already in Use

```
Address already in use: bind
```

**Solution:** Change the port in `application.yml`:
```yaml
server:
  port: 8081  # Use different port
```

### Issue: Cannot Login

Make sure you're using correct demo credentials:
- `user1` / `password1` (not `password`)
- Case-sensitive

### Issue: Authorization Code Expired

Authorization codes expire after 5 minutes (configurable). Start fresh from Step 5.2.

## Next Steps

1. **Read ARCHITECTURE.md** - Understand the system design
2. **Review the Source Code** - Check implementation details
3. **Implement Custom Claims** - Add business-specific claims
4. **Deploy to Production** - Follow security best practices
5. **Integrate with Your App** - Use the library in your application

## Using the Library in Your Project

### 1. Add Maven Dependency

```xml
<dependency>
    <groupId>com.example.oidc</groupId>
    <artifactId>oidc-lightweight-server-lib</artifactId>
    <version>1.0.0</version>
</dependency>
```

### 2. Configure MongoDB

```yaml
spring:
  data:
    mongodb:
      uri: mongodb://localhost:27017/my-idp
```

### 3. Enable Component Scanning

```java
@SpringBootApplication(scanBasePackages = {
    "com.mycompany.myapp",
    "com.example.oidc.lib"
})
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

### 4. Inject and Use Services

```java
@RestController
@RequiredArgsConstructor
public class MyController {
    private final ClientDetailsService clientDetailsService;
    private final JWTTokenService jwtTokenService;
    
    @PostMapping("/register-client")
    public ClientDetails registerClient(@RequestBody ClientDetails client) {
        return clientDetailsService.registerClient(client);
    }
}
```

## Common Use Cases

### Register a New Client Programmatically

```java
ClientDetails client = ClientDetails.builder()
    .clientId("my-app")
    .clientSecret("my-secret")
    .clientName("My Application")
    .redirectUris(Set.of("https://myapp.example.com/callback"))
    .allowedGrantTypes(Set.of("authorization_code", "refresh_token"))
    .responseTypes(Set.of("code"))
    .scopes(Set.of("openid", "profile", "email"))
    .applicationType("web")
    .subjectType("public")
    .tokenEndpointAuthMethod("client_secret_basic")
    .accessTokenValiditySeconds(3600)
    .idTokenValiditySeconds(600)
    .build();

clientDetailsService.registerClient(client);
```

### Create Custom ID Token Claims

```java
Map<String, Object> claims = new HashMap<>();
claims.put("organization", "acme-corp");
claims.put("department", "engineering");
claims.put("role", "admin");

JWT idToken = jwtTokenService.createIdToken(
    clientId, userId, issuer, audience, claims
);
```

### Validate and Parse JWT Token

```java
String token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...";

if (jwtTokenService.validateToken(token)) {
    JWT jwt = jwtTokenService.parseToken(token);
    String userId = jwt.getJWTClaimsSet().getSubject();
    // Use the token...
}
```

## Additional Resources

- [OpenID Connect Core 1.0](https://openid.net/specs/openid-connect-core-1_0.html)
- [OAuth 2.0 RFC 6749](https://tools.ietf.org/html/rfc6749)
- [Spring Security Documentation](https://spring.io/projects/spring-security)
- [MongoDB Documentation](https://docs.mongodb.com)

## Need Help?

1. Check logs: `tail -f logs/application.log`
2. Review the source code in `src/main/java`
3. Check ARCHITECTURE.md for design details
4. Read test cases for usage examples
