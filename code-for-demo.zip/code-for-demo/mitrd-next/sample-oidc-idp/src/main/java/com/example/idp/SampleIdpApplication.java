package com.example.idp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {
        "com.example.idp",
        "com.example.oidc.lib"
})
public class SampleIdpApplication {

    public static void main(String[] args) {
        SpringApplication.run(SampleIdpApplication.class, args);
    }
}
