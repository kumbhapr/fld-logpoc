package com.example.idp.controller;

import com.example.oidc.lib.model.AuthorizationCode;
import com.example.oidc.lib.model.ClientDetails;
import com.example.oidc.lib.service.AuthorizationCodeService;
import com.example.oidc.lib.service.ClientDetailsService;
import com.example.oidc.lib.service.JWTTokenService;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.SignedJWT;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.*;

@Controller
@Slf4j
@RequiredArgsConstructor
public class OIDCEndpointController {

    private final ClientDetailsService clientDetailsService;
    private final AuthorizationCodeService authorizationCodeService;
    private final JWTTokenService jwtTokenService;

    @Value("${server.servlet.context-path:}")
    private String contextPath;

    @Value("${server.port:8080}")
    private String serverPort;

    /**
     * Authorization Endpoint
     * GET /authorize
     */
    @GetMapping("/authorize")
    public String authorize(
            @RequestParam("client_id") String clientId,
            @RequestParam("response_type") String responseType,
            @RequestParam("redirect_uri") String redirectUri,
            @RequestParam(value = "scope", required = false) String scope,
            @RequestParam(value = "state", required = false) String state,
            @RequestParam(value = "nonce", required = false) String nonce,
            Model model,
            Authentication authentication) {

        // Validate client
        Optional<ClientDetails> clientOpt = clientDetailsService.getClientByClientId(clientId);
        if (!clientOpt.isPresent()) {
            return "error/invalid-client";
        }

        ClientDetails client = clientOpt.get();

        // Validate redirect URI
        if (!client.getRedirectUris().contains(redirectUri)) {
            return "error/invalid-redirect-uri";
        }

        // For authorization_code flow
        if ("code".equals(responseType)) {
            model.addAttribute("client_id", clientId);
            model.addAttribute("redirect_uri", redirectUri);
            model.addAttribute("scope", scope);
            model.addAttribute("state", state);
            model.addAttribute("nonce", nonce);
            model.addAttribute("response_type", responseType);
            
            // Show consent screen
            return "authorize-consent";
        }

        return "error/unsupported-response-type";
    }

    /**
     * Consent approval endpoint
     */
    @PostMapping("/authorize/approve")
    public String approveConsent(
            @RequestParam("client_id") String clientId,
            @RequestParam("redirect_uri") String redirectUri,
            @RequestParam(value = "scope", required = false) String scope,
            @RequestParam(value = "state", required = false) String state,
            @RequestParam(value = "nonce", required = false) String nonce,
            Authentication authentication) {

        String userId = authentication.getName();
        Set<String> scopes = scope != null ? new HashSet<>(Arrays.asList(scope.split(" "))) : new HashSet<>();

        // Create authorization code
        AuthorizationCode authCode = authorizationCodeService.createAuthorizationCode(
                clientId, userId, redirectUri, scopes
        );

        // Build redirect URI with authorization code
        String redirectUrl = redirectUri + "?code=" + authCode.getCode();
        if (state != null) {
            redirectUrl += "&state=" + state;
        }

        return "redirect:" + redirectUrl;
    }

    /**
     * Token Endpoint
     * POST /token
     */
    @PostMapping("/token")
    @ResponseBody
    public ResponseEntity<?> token(
            @RequestParam("grant_type") String grantType,
            @RequestParam(value = "code", required = false) String code,
            @RequestParam(value = "client_id", required = false) String clientId,
            @RequestParam(value = "client_secret", required = false) String clientSecret,
            @RequestParam(value = "redirect_uri", required = false) String redirectUri,
            @RequestParam(value = "refresh_token", required = false) String refreshToken) {

        if (!"authorization_code".equals(grantType)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "unsupported_grant_type"));
        }

        // Validate client credentials
        Optional<ClientDetails> clientOpt = clientDetailsService.getClientByClientId(clientId);
        if (!clientOpt.isPresent() || !clientOpt.get().getClientSecret().equals(clientSecret)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "invalid_client"));
        }

        // Validate authorization code
        Optional<AuthorizationCode> authCodeOpt = authorizationCodeService.getAuthorizationCode(code);
        if (!authCodeOpt.isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "invalid_code"));
        }

        AuthorizationCode authCode = authCodeOpt.get();

        // Verify redirect URI matches
        if (!authCode.getRedirectUri().equals(redirectUri)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "invalid_request"));
        }

        // Create tokens
        String issuer = "http://localhost:" + serverPort + contextPath;
        JWT idToken = jwtTokenService.createIdToken(clientId, authCode.getUserId(), issuer, clientId, 
                Map.of("email", authCode.getUserId() + "@example.com"));
        JWT accessToken = jwtTokenService.createAccessToken(clientId, authCode.getUserId(), issuer, authCode.getScopes());

        // Consume authorization code
        authorizationCodeService.consumeAuthorizationCode(code);

        Map<String, Object> response = new HashMap<>();
        response.put("access_token", accessToken.serialize());
        response.put("id_token", idToken.serialize());
        response.put("token_type", "Bearer");
        response.put("expires_in", 3600);

        return ResponseEntity.ok(response);
    }

    /**
     * UserInfo Endpoint
     * GET /userinfo
     */
    @GetMapping("/userinfo")
    @ResponseBody
    public ResponseEntity<?> userinfo(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "invalid_token"));
        }

        String token = authHeader.substring(7);
        
        // Validate token
        if (!jwtTokenService.validateToken(token)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "invalid_token"));
        }

        try {
            JWT jwt = jwtTokenService.parseToken(token);
            SignedJWT signedJWT = (SignedJWT) jwt;
            String userId = signedJWT.getJWTClaimsSet().getSubject();

            // Return user information
            Map<String, Object> userInfo = new HashMap<>();
            userInfo.put("sub", userId);
            userInfo.put("email", userId + "@example.com");
            userInfo.put("email_verified", true);
            userInfo.put("name", "Sample User");
            userInfo.put("given_name", "Sample");
            userInfo.put("family_name", "User");
            userInfo.put("locale", "en_US");

            return ResponseEntity.ok(userInfo);
        } catch (Exception e) {
            log.error("Error parsing token", e);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "invalid_token"));
        }
    }

    /**
     * OpenID Connect Configuration Endpoint
     * GET /.well-known/openid-configuration
     */
    @GetMapping("/.well-known/openid-configuration")
    @ResponseBody
    public Map<String, Object> openidConfiguration(HttpServletRequest request) {
        String issuer = "http://localhost:" + serverPort + contextPath;

        Map<String, Object> config = new HashMap<>();
        config.put("issuer", issuer);
        config.put("authorization_endpoint", issuer + "/authorize");
        config.put("token_endpoint", issuer + "/token");
        config.put("userinfo_endpoint", issuer + "/userinfo");
        config.put("jwks_uri", issuer + "/.well-known/jwks.json");
        config.put("response_types_supported", Arrays.asList("code", "id_token", "token id_token"));
        config.put("grant_types_supported", Arrays.asList("authorization_code", "implicit", "refresh_token"));
        config.put("subject_types_supported", Arrays.asList("public", "pairwise"));
        config.put("id_token_signing_alg_values_supported", Arrays.asList("RS256"));
        config.put("scopes_supported", Arrays.asList("openid", "profile", "email", "address", "phone"));
        config.put("token_endpoint_auth_methods_supported", Arrays.asList("client_secret_basic", "client_secret_post"));
        config.put("code_challenge_methods_supported", Arrays.asList("plain", "S256"));

        return config;
    }
}
