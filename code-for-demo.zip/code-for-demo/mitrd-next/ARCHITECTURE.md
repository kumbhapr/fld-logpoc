# Architecture Overview

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   Client Application (RP)                   │
│                   (Relying Party)                           │
└─────────────────────────┬───────────────────────────────────┘
                          │
                   OIDC Flow via HTTP(S)
                          │
        ┌─────────────────┼──────────────────┐
        │                 │                  │
        ▼                 ▼                  ▼
    /authorize        /token           /userinfo
        │                 │                  │
        └─────────────────┴──────────────────┘
                          │
        ┌─────────────────────────────────────────┐
        │   OIDC Lightweight Server Library       │
        │                                         │
        │  ┌─────────────────────────────────┐  │
        │  │   OIDC Endpoint Controllers      │  │
        │  │  - Authorization Endpoint       │  │
        │  │  - Token Endpoint              │  │
        │  │  - UserInfo Endpoint           │  │
        │  │  - Discovery Endpoint          │  │
        │  └─────────────────────────────────┘  │
        │                                         │
        │  ┌─────────────────────────────────┐  │
        │  │   Service Layer                  │  │
        │  │  - ClientDetailsService         │  │
        │  │  - AuthorizationCodeService     │  │
        │  │  - AccessTokenService           │  │
        │  │  - JWTTokenService             │  │
        │  │  - UserInfoService             │  │
        │  └─────────────────────────────────┘  │
        │                                         │
        │  ┌─────────────────────────────────┐  │
        │  │   Repository Layer (MongoDB)     │  │
        │  │  - ClientDetailsRepository       │  │
        │  │  - AuthorizationCodeRepository   │  │
        │  │  - AccessTokenRepository         │  │
        │  │  - RefreshTokenRepository        │  │
        │  │  - UserInfoRepository           │  │
        │  └─────────────────────────────────┘  │
        └─────────────────┬──────────────────────┘
                          │
        ┌─────────────────────────────────────────┐
        │        MongoDB                          │
        │  - Clients Collection                   │
        │  - Authorization Codes Collection       │
        │  - Access Tokens Collection             │
        │  - Refresh Tokens Collection            │
        │  - User Info Collection                 │
        └─────────────────────────────────────────┘
```

## OAuth 2.0 Authorization Code Flow

```
┌──────────────────────────────────────────────────────────────────┐
│                                                                  │
│  +───────────┐             +──────────────┐     ┌─────────────┐ │
│  │           │             │              │     │             │ │
│  │  Client   │             │  IDP (OIDC   │     │  Resource   │ │
│  │           │             │  Server)     │     │  Server     │ │
│  │           │             │              │     │ (UserInfo)  │ │
│  └─────┬─────┘             └──────┬───────┘     └──────┬──────┘ │
│        │                           │                    │        │
│        │   1. Redirect to          │                    │        │
│        │      /authorize           │                    │        │
│        ├──────────────────────────►│                    │        │
│        │                           │                    │        │
│        │  2. User Login            │                    │        │
│        │  & Consent                │                    │        │
│        │  (in browser)             │                    │        │
│        │                           │                    │        │
│        │  3. Redirect with         │                    │        │
│        │     auth code             │                    │        │
│        │◄──────────────────────────┤                    │        │
│        │                           │                    │        │
│        │  4. POST /token           │                    │        │
│        │     (code exchange)       │                    │        │
│        ├──────────────────────────►│                    │        │
│        │                           │                    │        │
│        │  5. Return tokens         │                    │        │
│        │     (id_token,            │                    │        │
│        │      access_token)        │                    │        │
│        │◄──────────────────────────┤                    │        │
│        │                           │                    │        │
│        │  6. GET /userinfo         │                    │        │
│        │     (Bearer token)        ├───────────────────►│        │
│        ├───────────────────────────┤                    │        │
│        │                           │  7. Return user    │        │
│        │  8. Receive user info     │      claims        │        │
│        │     claims                │◄───────────────────┤        │
│        │◄────────────────────────────────────────────────        │
│        │                           │                    │        │
└──────────────────────────────────────────────────────────────────┘
```

## Data Model

### ClientDetails
```
{
  _id: ObjectId,
  clientId: String,
  clientSecret: String,
  clientName: String,
  clientUri: String,
  logoUri: String,
  redirectUris: [String],
  postLogoutRedirectUris: [String],
  allowedGrantTypes: [String],
  responseTypes: [String],
  scopes: [String],
  applicationType: String,
  subjectType: String,
  tokenEndpointAuthMethod: String,
  idTokenSignedResponseAlg: String,
  accessTokenValiditySeconds: Integer,
  refreshTokenValiditySeconds: Integer,
  idTokenValiditySeconds: Integer,
  createdAt: Date,
  updatedAt: Date
}
```

### AuthorizationCode
```
{
  _id: ObjectId,
  code: String,
  clientId: String,
  userId: String,
  redirectUri: String,
  scopes: [String],
  issuedAt: Date,
  expiresAt: Date,
  approved: Boolean,
  codeChallenge: String,
  codeChallengeMethod: String
}
```

### AccessToken
```
{
  _id: ObjectId,
  tokenValue: String,
  clientId: String,
  userId: String,
  scopes: [String],
  issuedAt: Date,
  expiresAt: Date,
  refreshTokenId: String,
  additionalInformation: Object
}
```

### RefreshToken
```
{
  _id: ObjectId,
  tokenValue: String,
  clientId: String,
  userId: String,
  issuedAt: Date,
  expiresAt: Date
}
```

### UserInfo
```
{
  _id: ObjectId,
  userId: String,
  email: String,
  emailVerified: String,
  name: String,
  givenName: String,
  familyName: String,
  middleName: String,
  nickname: String,
  preferredUsername: String,
  profile: String,
  picture: String,
  website: String,
  gender: String,
  birthdate: String,
  zoneinfo: String,
  locale: String,
  phoneNumber: String,
  phoneNumberVerified: String,
  formattedAddress: String,
  streetAddress: String,
  locality: String,
  region: String,
  postalCode: String,
  country: String,
  updatedAt: Date
}
```

## JWT Token Structure

### ID Token
```
Header:
{
  "alg": "RS256",
  "typ": "JWT"
}

Payload:
{
  "sub": "user_id",
  "iss": "http://idp.example.com",
  "aud": "client_id",
  "exp": 1234567890,
  "iat": 1234567890,
  "client_id": "client_id",
  "email": "user@example.com",
  // custom claims
}

Signature: RSASHA256(base64(header) + "." + base64(payload))
```

### Access Token
```
Header:
{
  "alg": "RS256",
  "typ": "JWT"
}

Payload:
{
  "sub": "user_id",
  "iss": "http://idp.example.com",
  "exp": 1234567890,
  "iat": 1234567890,
  "client_id": "client_id",
  "scope": "openid profile email"
}

Signature: RSASHA256(base64(header) + "." + base64(payload))
```

## Security Implementation

### Authentication Flow
1. User provides credentials (username/password)
2. Spring Security validates against UserDetailsService
3. Session is created
4. User is redirected to consent screen

### Authorization Code Validation
1. Authorization code is generated with 5-minute expiry
2. Code is single-use (consumed after token exchange)
3. Redirect URI must match registered URI
4. Client credentials must be valid

### Token Generation
1. JWT tokens are signed with RSA-2048 private key
2. Public key available via JWKS endpoint
3. Tokens include expiration time
4. Tokens are validated on every request

### Scope Enforcement
1. Scopes requested in authorization
2. Scopes included in token
3. Scopes validated in UserInfo endpoint

## Deployment Architecture (Production)

```
┌──────────────────────────────────────────────────────────────┐
│                       Load Balancer                          │
│                    (SSL/TLS Termination)                     │
└────┬──────────────────────────────────────────────────────┬──┘
     │                                                        │
     ▼                                                        ▼
┌──────────────────────┐                          ┌──────────────────────┐
│  IDP Instance 1      │                          │  IDP Instance 2      │
│  (Spring Boot App)   │                          │  (Spring Boot App)   │
└────┬─────────────────┘                          └──────┬───────────────┘
     │                                                    │
     └────────────────┬───────────────────────────────────┘
                      │
        ┌─────────────────────────────────────────┐
        │    MongoDB Replica Set                  │
        │  ┌──────────┐  ┌──────────┐             │
        │  │ Primary  │  │Secondary │  ...       │
        │  └──────────┘  └──────────┘             │
        └─────────────────────────────────────────┘
```

## Performance Optimization

1. **Caching Strategy**
   - Cache client details (TTL: 1 hour)
   - Cache JWT public keys (TTL: 24 hours)
   - Cache user information (TTL: 30 minutes)

2. **Database Indexing**
   - Index on clientId
   - Index on code (authorization codes)
   - Index on tokenValue (access/refresh tokens)
   - Index on userId (user info)

3. **Connection Pooling**
   - MongoDB connection pool (min: 10, max: 50)
   - HTTP connection pooling for external services

4. **Async Processing**
   - Async audit logging
   - Async token cleanup jobs (hourly)

## Monitoring & Logging

1. **Key Metrics**
   - Authorization requests per minute
   - Token exchange success rate
   - UserInfo endpoint response time
   - MongoDB query performance

2. **Log Levels**
   - ERROR: Authentication failures, token validation failures
   - WARN: Suspicious activities, rate limit near
   - INFO: Authorization grants, token exchanges
   - DEBUG: Detailed request/response data

## Backup & Recovery

1. **MongoDB Backup**
   - Daily full backups
   - Hourly incremental backups
   - Test recovery procedures monthly

2. **Disaster Recovery**
   - RTO: 1 hour
   - RPO: 15 minutes
   - Automated failover to secondary region

## Compliance

1. **OIDC Certification**
   - Compliant with OpenID Connect Core 1.0
   - Implements best practices from OIDC specs

2. **Security Standards**
   - NIST Cybersecurity Framework
   - OWASP Top 10 mitigation
   - OAuth 2.0 Security Best Practices

3. **Data Protection**
   - GDPR compliance for user data
   - Encryption at rest and in transit
   - Secure password storage (bcrypt)
