# Production Deployment Guide

This guide outlines best practices for deploying the OIDC Lightweight Server Library and Sample IDP to production.

## Security Configuration

### 1. HTTPS/TLS Configuration

Update `application.yml`:

```yaml
server:
  port: 8443
  ssl:
    key-store: classpath:keystore.p12
    key-store-password: your-secure-password
    key-store-type: PKCS12
    key-alias: tomcat
```

Generate a certificate:

```bash
keytool -genkey -alias tomcat -storetype PKCS12 \
  -keyalg RSA -keysize 2048 -keystore keystore.p12 \
  -validity 365 -keypass password -storepass password
```

### 2. Environment Variables

Use environment variables for sensitive configuration:

```bash
export MONGODB_URI=mongodb://username:password@mongodb.example.com:27017/prod-db
export JWT_PRIVATE_KEY=$(cat /secure/path/to/private.key)
export JWT_PUBLIC_KEY=$(cat /secure/path/to/public.key)
export CLIENT_SECRET_ENCRYPTION_KEY=$(openssl rand -hex 32)
```

### 3. Spring Security Configuration

```yaml
spring:
  security:
    require-ssl: true
    
security:
  cors:
    allowed-origins: https://trusted-domain.com
    allowed-methods: GET,POST,DELETE,PUT
    max-age: 3600
    
server:
  servlet:
    session:
      timeout: 30m
      cookie:
        http-only: true
        secure: true
        same-site: strict
```

## Database Configuration

### MongoDB Production Setup

#### Replica Set Configuration

```yaml
spring:
  data:
    mongodb:
      uri: mongodb://user:password@mongo1:27017,mongo2:27017,mongo3:27017/prod-db?replicaSet=rs0&authSource=admin
```

#### Indexing Strategy

Create indexes for optimal performance:

```javascript
// In MongoDB shell
use prod-db;

// Client Details
db.clients.createIndex({ clientId: 1 }, { unique: true });
db.clients.createIndex({ createdAt: 1 });

// Authorization Codes
db.authorization_codes.createIndex({ code: 1 }, { unique: true });
db.authorization_codes.createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 });
db.authorization_codes.createIndex({ clientId: 1 });
db.authorization_codes.createIndex({ userId: 1 });

// Access Tokens
db.access_tokens.createIndex({ tokenValue: 1 }, { unique: true });
db.access_tokens.createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 });
db.access_tokens.createIndex({ userId: 1 });

// Refresh Tokens
db.refresh_tokens.createIndex({ tokenValue: 1 }, { unique: true });
db.refresh_tokens.createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 });

// User Info
db.user_info.createIndex({ userId: 1 }, { unique: true });
```

#### Backup Strategy

```bash
#!/bin/bash
# Daily backup script
BACKUP_DIR="/backups/mongodb"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mongodump --uri="mongodb://user:pass@localhost:27017/prod-db" \
  --out="$BACKUP_DIR/backup_$TIMESTAMP"

# Keep only last 30 days
find $BACKUP_DIR -type d -mtime +30 -exec rm -rf {} \;
```

## Application Configuration

### Production application.yml

```yaml
spring:
  application:
    name: OIDC IDP
  data:
    mongodb:
      uri: ${MONGODB_URI}
      auto-index-creation: false
  jpa:
    show-sql: false
  thymeleaf:
    cache: true
    
  security:
    oauth2:
      resourceserver:
        jwt:
          issuer-uri: https://idp.example.com

server:
  port: 8443
  ssl:
    enabled: true
    key-store: /etc/secrets/keystore.p12
    key-store-password: ${KEYSTORE_PASSWORD}
  servlet:
    context-path: /idp
  compression:
    enabled: true
    min-response-size: 1024
    
logging:
  level:
    root: WARN
    com.example.idp: INFO
    com.example.oidc.lib: INFO
  file:
    name: /var/log/oidc-idp/application.log
    max-size: 100MB
    max-history: 30
    total-size-cap: 10GB
    
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics
      base-path: /actuator
  endpoint:
    health:
      show-details: when-authorized
  metrics:
    export:
      prometheus:
        enabled: true
        
oidc:
  issuer: https://idp.example.com
  token:
    id-token-validity-seconds: 600
    access-token-validity-seconds: 3600
    authorization-code-validity-seconds: 300
    refresh-token-validity-seconds: 2592000
```

## Deployment Architecture

### Docker Deployment

Create `Dockerfile`:

```dockerfile
FROM openjdk:11-jre-slim

WORKDIR /app

COPY target/sample-oidc-idp-1.0.0.jar app.jar

ENV SPRING_PROFILES_ACTIVE=production
ENV SERVER_PORT=8443

EXPOSE 8443

HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f -k https://localhost:8443/idp/actuator/health || exit 1

ENTRYPOINT ["java", "-jar", "app.jar"]
```

Build and push:

```bash
docker build -t oidc-idp:1.0.0 .
docker push registry.example.com/oidc-idp:1.0.0
```

### Kubernetes Deployment

Create `deployment.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: oidc-idp
  namespace: production
spec:
  replicas: 3
  selector:
    matchLabels:
      app: oidc-idp
  template:
    metadata:
      labels:
        app: oidc-idp
    spec:
      containers:
      - name: oidc-idp
        image: registry.example.com/oidc-idp:1.0.0
        ports:
        - containerPort: 8443
        env:
        - name: MONGODB_URI
          valueFrom:
            secretKeyRef:
              name: oidc-secrets
              key: mongodb-uri
        - name: KEYSTORE_PASSWORD
          valueFrom:
            secretKeyRef:
              name: oidc-secrets
              key: keystore-password
        livenessProbe:
          httpGet:
            path: /idp/actuator/health
            port: 8443
            scheme: HTTPS
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /idp/actuator/health
            port: 8443
            scheme: HTTPS
          initialDelaySeconds: 10
          periodSeconds: 5
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
---
apiVersion: v1
kind: Service
metadata:
  name: oidc-idp-service
  namespace: production
spec:
  type: LoadBalancer
  ports:
  - port: 443
    targetPort: 8443
    protocol: TCP
  selector:
    app: oidc-idp
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: oidc-idp-network-policy
  namespace: production
spec:
  podSelector:
    matchLabels:
      app: oidc-idp
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: production
    - podSelector:
        matchLabels:
          app: ingress-controller
  egress:
  - to:
    - namespaceSelector:
        matchLabels:
          name: production
  - to:
    - podSelector: {}
    ports:
    - protocol: TCP
      port: 27017  # MongoDB
```

## Monitoring & Logging

### Metrics Collection

Enable Prometheus metrics:

```yaml
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,prometheus
  metrics:
    export:
      prometheus:
        enabled: true
```

Prometheus scrape config:

```yaml
scrape_configs:
  - job_name: 'oidc-idp'
    scheme: https
    tls_config:
      insecure_skip_verify: true
    static_configs:
      - targets: ['idp.example.com:8443']
    metrics_path: '/idp/actuator/prometheus'
```

### Logging Stack (ELK)

Install and configure Logback for ELK:

```xml
<!-- logback-spring.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <springProperty name="LOG_FILE" source="logging.file.name"/>
  
  <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <file>${LOG_FILE}</file>
    <encoder>
      <pattern>%d{ISO8601} %p %c{1}:%L - %m%n</pattern>
    </encoder>
    <rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
      <fileNamePattern>${LOG_FILE}.%d{yyyy-MM-dd}.%i.gz</fileNamePattern>
      <maxFileSize>100MB</maxFileSize>
      <maxHistory>30</maxHistory>
      <totalSizeCap>10GB</totalSizeCap>
    </rollingPolicy>
  </appender>

  <appender name="LOGSTASH" class="net.logstash.logback.appender.LogstashTcpSocketAppender">
    <destination>logstash.example.com:5000</destination>
    <encoder class="net.logstash.logback.encoder.LogstashEncoder"/>
  </appender>

  <root level="INFO">
    <appender-ref ref="FILE"/>
    <appender-ref ref="LOGSTASH"/>
  </root>
</configuration>
```

Add dependency:

```xml
<dependency>
    <groupId>net.logstash.logback</groupId>
    <artifactId>logstash-logback-encoder</artifactId>
    <version>7.2</version>
</dependency>
```

## Performance Tuning

### JVM Tuning

```bash
export JAVA_OPTS="-Xmx1g -Xms512m \
  -XX:+UseG1GC \
  -XX:MaxGCPauseMillis=200 \
  -XX:+ParallelRefProcEnabled \
  -XX:+UnlockDiagnosticVMOptions \
  -XX:G1SummarizeRSetStatsPeriod=1"
```

### Connection Pooling

```yaml
spring:
  data:
    mongodb:
      connection-string: ${MONGODB_URI}
      # Connection pool settings handled by MongoDB driver
```

### Caching

Add Spring Cache support:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-cache</artifactId>
</dependency>
```

```yaml
spring:
  cache:
    type: caffeine
    caffeine:
      spec: "maximumSize=500,expireAfterWrite=10m"
```

## Disaster Recovery

### Automated Backups

```bash
#!/bin/bash
# backup.sh
BACKUP_PATH="/backups/mongodb"
DATE=$(date +%Y%m%d_%H%M%S)

# Full backup
mongodump --uri="${MONGODB_URI}" --out="${BACKUP_PATH}/${DATE}"

# Upload to S3
aws s3 sync "${BACKUP_PATH}/${DATE}" "s3://backup-bucket/oidc/${DATE}/"

# Clean old backups (keep 30 days)
find "${BACKUP_PATH}" -type d -mtime +30 -exec rm -rf {} \;
```

### Point-in-Time Recovery

```bash
#!/bin/bash
# restore.sh
BACKUP_DATE=$1
RESTORE_PATH="/tmp/restore"

# Download from S3
aws s3 sync "s3://backup-bucket/oidc/${BACKUP_DATE}/" "${RESTORE_PATH}/"

# Restore
mongorestore --uri="${MONGODB_URI}" --dir="${RESTORE_PATH}/${BACKUP_DATE}"
```

## Security Hardening

### Rate Limiting

```yaml
ratelimit:
  enabled: true
  requests-per-minute: 100
  requests-per-hour: 10000
```

### WAF Rules

Configure for common threats:

```
# Block SQL injection
SecRule ARGS "(\bOR\b|1=1|drop table)" "id:1000,phase:2,deny"

# Block XSS attempts
SecRule ARGS "<script" "id:1001,phase:2,deny"

# Rate limiting
SecRule IP:@throttle "1000" "id:1002,phase:5,deny,status:429"
```

### CORS Configuration

```java
@Configuration
public class CorsConfiguration {
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/idp/**")
                    .allowedOrigins("https://trusted-domain.com")
                    .allowedMethods("GET", "POST")
                    .maxAge(3600)
                    .allowCredentials(true);
            }
        };
    }
}
```

## Compliance & Auditing

### Audit Logging

```java
@Aspect
@Component
public class AuditAspect {
    private static final Logger logger = LoggerFactory.getLogger("AUDIT");
    
    @AfterReturning("execution(* com.example.idp.controller.*.*(..))")
    public void auditLog(JoinPoint joinPoint) {
        logger.info("User action: {} by {} at {}",
            joinPoint.getSignature(),
            getCurrentUser(),
            LocalDateTime.now());
    }
}
```

### Data Retention

```yaml
retention:
  authorization-codes: 30  # days
  access-tokens: 90
  refresh-tokens: 365
  audit-logs: 2555  # 7 years
```

## Load Testing

Use Apache JMeter for load testing:

```bash
jmeter -n -t load-test.jmx -l results.jtl -Jusers=100 -Jduration=300
```

## Monitoring Checklist

- [ ] Monitor authentication success/failure rates
- [ ] Track token generation performance
- [ ] Monitor database query performance
- [ ] Alert on high error rates (>1%)
- [ ] Track certificate expiration dates
- [ ] Monitor disk space usage
- [ ] Alert on failed backups
- [ ] Monitor security events

## Deployment Checklist

- [ ] SSL/TLS certificates installed
- [ ] MongoDB replica set configured
- [ ] Backups automated and tested
- [ ] Monitoring and alerting configured
- [ ] Load balancer configured
- [ ] WAF rules deployed
- [ ] DDoS protection enabled
- [ ] Secrets managed securely
- [ ] Logs aggregated to centralized system
- [ ] Documentation updated
- [ ] Team trained on operations
- [ ] Disaster recovery tested

## Support & Troubleshooting

For issues in production:

1. Check application logs: `/var/log/oidc-idp/application.log`
2. Check MongoDB connectivity
3. Verify SSL certificates not expired
4. Check JVM heap usage
5. Review recent deployments/configuration changes

Contact the support team with:
- Error message and stack trace
- Timestamp of the issue
- Number of affected users
- Recent changes made
