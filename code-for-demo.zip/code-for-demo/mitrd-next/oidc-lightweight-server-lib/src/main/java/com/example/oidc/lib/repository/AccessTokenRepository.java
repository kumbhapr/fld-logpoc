package com.example.oidc.lib.repository;

import com.example.oidc.lib.model.AccessToken;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AccessTokenRepository extends MongoRepository<AccessToken, String> {
    Optional<AccessToken> findByTokenValue(String tokenValue);
}
