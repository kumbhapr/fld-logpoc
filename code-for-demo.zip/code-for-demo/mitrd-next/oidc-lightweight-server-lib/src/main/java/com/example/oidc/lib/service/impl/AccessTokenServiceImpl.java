package com.example.oidc.lib.service.impl;

import com.example.oidc.lib.model.AccessToken;
import com.example.oidc.lib.repository.AccessTokenRepository;
import com.example.oidc.lib.service.AccessTokenService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccessTokenServiceImpl implements AccessTokenService {

    private final AccessTokenRepository accessTokenRepository;

    @Value("${oidc.token.access-token-validity-seconds:3600}")
    private Integer accessTokenValiditySeconds;

    @Override
    public AccessToken createAccessToken(String clientId, String userId, Set<String> scopes) {
        String tokenValue = generateTokenValue();
        Date now = new Date();
        Date expiresAt = new Date(now.getTime() + (accessTokenValiditySeconds * 1000L));

        AccessToken token = AccessToken.builder()
                .tokenValue(tokenValue)
                .clientId(clientId)
                .userId(userId)
                .scopes(scopes)
                .issuedAt(now)
                .expiresAt(expiresAt)
                .build();

        log.info("Created access token for client: {}, user: {}", clientId, userId);
        return accessTokenRepository.save(token);
    }

    @Override
    public Optional<AccessToken> getAccessToken(String tokenValue) {
        return accessTokenRepository.findByTokenValue(tokenValue);
    }

    @Override
    public void revokeAccessToken(String tokenValue) {
        accessTokenRepository.findByTokenValue(tokenValue)
                .ifPresent(token -> {
                    accessTokenRepository.deleteById(token.getId());
                    log.info("Revoked access token for user: {}", token.getUserId());
                });
    }

    @Override
    public void revokeAllAccessTokensForUser(String userId) {
        accessTokenRepository.findAll().stream()
                .filter(token -> userId.equals(token.getUserId()))
                .forEach(token -> accessTokenRepository.deleteById(token.getId()));
        log.info("Revoked all access tokens for user: {}", userId);
    }

    private String generateTokenValue() {
        return DigestUtils.sha256Hex(UUID.randomUUID().toString());
    }
}
