package com.example.oidc.lib.service.impl;

import com.example.oidc.lib.service.JWTTokenService;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;
import java.util.Date;
import java.util.Map;
import java.util.Set;

@Service
@Slf4j
public class JWTTokenServiceImpl implements JWTTokenService {

    private final RSAPrivateKey privateKey;
    private final RSAPublicKey publicKey;

    @Value("${oidc.token.id-token-validity-seconds:600}")
    private Integer idTokenValiditySeconds;

    @Value("${oidc.token.access-token-validity-seconds:3600}")
    private Integer accessTokenValiditySeconds;

    public JWTTokenServiceImpl() throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair keyPair = keyGen.generateKeyPair();
        this.privateKey = (RSAPrivateKey) keyPair.getPrivate();
        this.publicKey = (RSAPublicKey) keyPair.getPublic();
        log.info("Initialized JWT Token Service with RSA-2048 key pair");
    }

    @Override
    public JWT createIdToken(String clientId, String userId, String issuer, String audience, Map<String, Object> claims) {
        Date now = new Date();
        Date expiresAt = new Date(now.getTime() + (idTokenValiditySeconds * 1000L));

        JWTClaimsSet.Builder claimsBuilder = new JWTClaimsSet.Builder()
                .subject(userId)
                .issuer(issuer)
                .audience(audience)
                .expirationTime(expiresAt)
                .issueTime(now)
                .claim("client_id", clientId);

        if (claims != null) {
            claims.forEach(claimsBuilder::claim);
        }

        JWTClaimsSet claimsSet = claimsBuilder.build();
        
        return createSignedJWT(claimsSet);
    }

    @Override
    public JWT createAccessToken(String clientId, String userId, String issuer, Set<String> scopes) {
        Date now = new Date();
        Date expiresAt = new Date(now.getTime() + (accessTokenValiditySeconds * 1000L));

        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .subject(userId)
                .issuer(issuer)
                .expirationTime(expiresAt)
                .issueTime(now)
                .claim("client_id", clientId)
                .claim("scope", String.join(" ", scopes))
                .build();

        return createSignedJWT(claimsSet);
    }

    @Override
    public JWT createUserInfoJWT(String userId, String issuer, Map<String, Object> userClaims) {
        Date now = new Date();
        Date expiresAt = new Date(now.getTime() + 3600000); // 1 hour

        JWTClaimsSet.Builder claimsBuilder = new JWTClaimsSet.Builder()
                .subject(userId)
                .issuer(issuer)
                .expirationTime(expiresAt)
                .issueTime(now);

        if (userClaims != null) {
            userClaims.forEach(claimsBuilder::claim);
        }

        JWTClaimsSet claimsSet = claimsBuilder.build();
        return createSignedJWT(claimsSet);
    }

    @Override
    public JWT parseToken(String tokenValue) {
        try {
            return SignedJWT.parse(tokenValue);
        } catch (ParseException e) {
            log.error("Failed to parse token", e);
            throw new IllegalArgumentException("Invalid token format", e);
        }
    }

    @Override
    public boolean validateToken(String tokenValue) {
        try {
            SignedJWT signedJWT = SignedJWT.parse(tokenValue);
            if (signedJWT == null) {
                return false;
            }

            JWTClaimsSet claimsSet = signedJWT.getJWTClaimsSet();

            // Check expiration
            if (claimsSet.getExpirationTime() != null && 
                new Date().after(claimsSet.getExpirationTime())) {
                return false;
            }

            // Verify signature
            return signedJWT.verify(new RSASSAVerifier(publicKey));
        } catch (Exception e) {
            log.debug("Token validation failed", e);
            return false;
        }
    }

    private JWT createSignedJWT(JWTClaimsSet claimsSet) {
        try {
            JWSHeader header = new JWSHeader(JWSAlgorithm.RS256);
            SignedJWT signedJWT = new SignedJWT(header, claimsSet);
            signedJWT.sign(new RSASSASigner(privateKey));
            return signedJWT;
        } catch (JOSEException e) {
            log.error("Failed to create signed JWT", e);
            throw new RuntimeException("Failed to create signed JWT", e);
        }
    }

    public RSAPublicKey getPublicKey() {
        return publicKey;
    }
}
