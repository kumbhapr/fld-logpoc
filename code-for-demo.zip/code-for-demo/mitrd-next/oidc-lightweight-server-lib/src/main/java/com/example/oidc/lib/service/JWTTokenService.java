package com.example.oidc.lib.service;

import com.nimbusds.jwt.JWT;

import java.util.Map;
import java.util.Set;

public interface JWTTokenService {
    JWT createIdToken(String clientId, String userId, String issuer, String audience, Map<String, Object> claims);
    JWT createAccessToken(String clientId, String userId, String issuer, Set<String> scopes);
    JWT createUserInfoJWT(String userId, String issuer, Map<String, Object> userClaims);
    JWT parseToken(String tokenValue);
    boolean validateToken(String tokenValue);
}
