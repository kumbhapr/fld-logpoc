package com.example.oidc.lib.service.impl;

import com.example.oidc.lib.model.UserInfo;
import com.example.oidc.lib.repository.UserInfoRepository;
import com.example.oidc.lib.service.UserInfoService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserInfoServiceImpl implements UserInfoService {

    private final UserInfoRepository userInfoRepository;

    @Override
    public UserInfo saveUserInfo(UserInfo userInfo) {
        userInfo.setUpdatedAt(new Date());
        log.info("Saving user info for user: {}", userInfo.getUserId());
        return userInfoRepository.save(userInfo);
    }

    @Override
    public Optional<UserInfo> getUserInfo(String userId) {
        return userInfoRepository.findByUserId(userId);
    }

    @Override
    public UserInfo updateUserInfo(UserInfo userInfo) {
        userInfo.setUpdatedAt(new Date());
        log.info("Updating user info for user: {}", userInfo.getUserId());
        return userInfoRepository.save(userInfo);
    }

    @Override
    public void deleteUserInfo(String userId) {
        log.info("Deleting user info for user: {}", userId);
        userInfoRepository.findByUserId(userId)
                .ifPresent(userInfo -> userInfoRepository.deleteById(userInfo.getId()));
    }
}
