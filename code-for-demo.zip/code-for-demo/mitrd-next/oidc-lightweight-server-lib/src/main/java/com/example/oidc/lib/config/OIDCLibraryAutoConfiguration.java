package com.example.oidc.lib.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;

@Configuration
@EnableAuthorizationServer
@EnableMongoRepositories(basePackages = "com.example.oidc.lib.repository")
public class OIDCLibraryAutoConfiguration {
    // Auto-configuration for OIDC Library components
}
