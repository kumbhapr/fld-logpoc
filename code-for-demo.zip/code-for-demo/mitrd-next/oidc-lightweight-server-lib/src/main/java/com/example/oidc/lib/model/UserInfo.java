package com.example.oidc.lib.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

/**
 * User Info Entity
 */
@Document(collection = "user_info")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserInfo {

    @Id
    private String id;

    private String userId;
    private String email;
    private String emailVerified;
    private String name;
    private String givenName;
    private String familyName;
    private String middleName;
    private String nickname;
    private String preferredUsername;
    private String profile;
    private String picture;
    private String website;
    private String gender;
    private String birthdate;
    private String zoneinfo;
    private String locale;
    private String phoneNumber;
    private String phoneNumberVerified;
    private String formattedAddress;
    private String streetAddress;
    private String locality;
    private String region;
    private String postalCode;
    private String country;
    private Date updatedAt;
}
