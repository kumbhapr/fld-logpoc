package com.example.oidc.lib.service;

import com.example.oidc.lib.model.ClientDetails;

import java.util.Optional;

public interface ClientDetailsService {
    ClientDetails registerClient(ClientDetails client);
    Optional<ClientDetails> getClientByClientId(String clientId);
    ClientDetails updateClient(ClientDetails client);
    void deleteClient(String clientId);
}
