package com.example.oidc.lib.repository;

import com.example.oidc.lib.model.ClientDetails;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ClientDetailsRepository extends MongoRepository<ClientDetails, String> {
    Optional<ClientDetails> findByClientId(String clientId);
}
