package com.example.oidc.lib.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.Map;
import java.util.Set;

/**
 * OAuth2 Access Token Entity
 */
@Document(collection = "access_tokens")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccessToken {

    @Id
    private String id;

    private String tokenValue;
    private String clientId;
    private String userId;
    private Set<String> scopes;
    private Date issuedAt;
    private Date expiresAt;
    private String refreshTokenId;
    private Map<String, Object> additionalInformation;
    
    public boolean isExpired() {
        return expiresAt != null && new Date().after(expiresAt);
    }
}
