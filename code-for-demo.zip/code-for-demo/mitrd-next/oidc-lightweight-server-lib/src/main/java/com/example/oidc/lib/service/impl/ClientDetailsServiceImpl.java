package com.example.oidc.lib.service.impl;

import com.example.oidc.lib.model.ClientDetails;
import com.example.oidc.lib.repository.ClientDetailsRepository;
import com.example.oidc.lib.service.ClientDetailsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClientDetailsServiceImpl implements ClientDetailsService {

    private final ClientDetailsRepository clientDetailsRepository;

    @Override
    public ClientDetails registerClient(ClientDetails client) {
        client.setCreatedAt(new Date());
        client.setUpdatedAt(new Date());
        log.info("Registering new client: {}", client.getClientId());
        return clientDetailsRepository.save(client);
    }

    @Override
    public Optional<ClientDetails> getClientByClientId(String clientId) {
        return clientDetailsRepository.findByClientId(clientId);
    }

    @Override
    public ClientDetails updateClient(ClientDetails client) {
        client.setUpdatedAt(new Date());
        log.info("Updating client: {}", client.getClientId());
        return clientDetailsRepository.save(client);
    }

    @Override
    public void deleteClient(String clientId) {
        log.info("Deleting client: {}", clientId);
        clientDetailsRepository.findByClientId(clientId)
                .ifPresent(client -> clientDetailsRepository.deleteById(client.getId()));
    }
}
