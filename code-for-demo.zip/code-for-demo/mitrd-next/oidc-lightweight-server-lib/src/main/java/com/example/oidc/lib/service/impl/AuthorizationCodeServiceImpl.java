package com.example.oidc.lib.service.impl;

import com.example.oidc.lib.model.AuthorizationCode;
import com.example.oidc.lib.repository.AuthorizationCodeRepository;
import com.example.oidc.lib.service.AuthorizationCodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthorizationCodeServiceImpl implements AuthorizationCodeService {

    private final AuthorizationCodeRepository authorizationCodeRepository;

    @Value("${oidc.token.authorization-code-validity-seconds:300}")
    private Integer authorizationCodeValiditySeconds;

    @Override
    public AuthorizationCode createAuthorizationCode(String clientId, String userId, String redirectUri, Set<String> scopes) {
        String code = generateAuthorizationCode();
        Date now = new Date();
        Date expiresAt = new Date(now.getTime() + (authorizationCodeValiditySeconds * 1000L));

        AuthorizationCode authCode = AuthorizationCode.builder()
                .code(code)
                .clientId(clientId)
                .userId(userId)
                .redirectUri(redirectUri)
                .scopes(scopes)
                .issuedAt(now)
                .expiresAt(expiresAt)
                .approved(true)
                .build();

        log.info("Created authorization code for client: {}, user: {}", clientId, userId);
        return authorizationCodeRepository.save(authCode);
    }

    @Override
    public Optional<AuthorizationCode> getAuthorizationCode(String code) {
        Optional<AuthorizationCode> authCode = authorizationCodeRepository.findByCode(code);
        if (authCode.isPresent() && !authCode.get().isExpired()) {
            return authCode;
        }
        return Optional.empty();
    }

    @Override
    public void consumeAuthorizationCode(String code) {
        authorizationCodeRepository.findByCode(code)
                .ifPresent(authCode -> {
                    authorizationCodeRepository.deleteById(authCode.getId());
                    log.info("Consumed authorization code for user: {}", authCode.getUserId());
                });
    }

    @Override
    public void revokeAuthorizationCode(String code) {
        authorizationCodeRepository.findByCode(code)
                .ifPresent(authCode -> {
                    authorizationCodeRepository.deleteById(authCode.getId());
                    log.info("Revoked authorization code for user: {}", authCode.getUserId());
                });
    }

    private String generateAuthorizationCode() {
        return DigestUtils.sha256Hex(UUID.randomUUID().toString()).substring(0, 32);
    }
}
