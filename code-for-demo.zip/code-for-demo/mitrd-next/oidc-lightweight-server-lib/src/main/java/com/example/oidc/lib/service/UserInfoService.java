package com.example.oidc.lib.service;

import com.example.oidc.lib.model.UserInfo;

import java.util.Optional;

public interface UserInfoService {
    UserInfo saveUserInfo(UserInfo userInfo);
    Optional<UserInfo> getUserInfo(String userId);
    UserInfo updateUserInfo(UserInfo userInfo);
    void deleteUserInfo(String userId);
}
