package com.example.oidc.lib.service;

import com.example.oidc.lib.model.AuthorizationCode;

import java.util.Optional;
import java.util.Set;

public interface AuthorizationCodeService {
    AuthorizationCode createAuthorizationCode(String clientId, String userId, String redirectUri, Set<String> scopes);
    Optional<AuthorizationCode> getAuthorizationCode(String code);
    void consumeAuthorizationCode(String code);
    void revokeAuthorizationCode(String code);
}
