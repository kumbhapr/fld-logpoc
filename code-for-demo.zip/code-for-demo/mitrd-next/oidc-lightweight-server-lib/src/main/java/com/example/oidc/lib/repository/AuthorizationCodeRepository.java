package com.example.oidc.lib.repository;

import com.example.oidc.lib.model.AuthorizationCode;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AuthorizationCodeRepository extends MongoRepository<AuthorizationCode, String> {
    Optional<AuthorizationCode> findByCode(String code);
}
