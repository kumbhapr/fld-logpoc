package com.example.oidc.lib.service;

import com.example.oidc.lib.model.AccessToken;

import java.util.Optional;

public interface AccessTokenService {
    AccessToken createAccessToken(String clientId, String userId, java.util.Set<String> scopes);
    Optional<AccessToken> getAccessToken(String tokenValue);
    void revokeAccessToken(String tokenValue);
    void revokeAllAccessTokensForUser(String userId);
}
