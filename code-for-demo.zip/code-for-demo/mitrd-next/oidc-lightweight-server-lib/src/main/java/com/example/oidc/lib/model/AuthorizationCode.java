package com.example.oidc.lib.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.Set;

/**
 * Authorization Code Entity
 */
@Document(collection = "authorization_codes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthorizationCode {

    @Id
    private String id;

    private String code;
    private String clientId;
    private String userId;
    private String redirectUri;
    private Set<String> scopes;
    private Date issuedAt;
    private Date expiresAt;
    private Boolean approved;
    private String codeChallenge;
    private String codeChallengeMethod;
    
    public boolean isExpired() {
        return expiresAt != null && new Date().after(expiresAt);
    }
}
