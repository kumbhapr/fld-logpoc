package com.example.oidc.lib.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.Set;

/**
 * OAuth2 Client Details Entity
 * Maps client applications registered with the OIDC server
 */
@Document(collection = "clients")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ClientDetails {

    @Id
    private String id;

    private String clientId;
    private String clientSecret;
    private String clientName;
    private String clientUri;
    private String logoUri;
    private Set<String> redirectUris;
    private Set<String> postLogoutRedirectUris;
    private Set<String> allowedGrantTypes;
    private Set<String> responseTypes;
    private Set<String> scopes;
    private String applicationType;
    private String subjectType;
    private String tokenEndpointAuthMethod;
    
    // JWT Signing algorithms
    private String idTokenSignedResponseAlg;
    private String idTokenEncryptedResponseAlg;
    private String idTokenEncryptedResponseEnc;
    private String userInfoSignedResponseAlg;
    private String userInfoEncryptedResponseAlg;
    private String userInfoEncryptedResponseEnc;
    private String requestObjectSigningAlg;
    
    // Token lifetimes (in seconds)
    private Integer accessTokenValiditySeconds;
    private Integer refreshTokenValiditySeconds;
    private Integer idTokenValiditySeconds;
    
    // Metadata URLs
    private String jwksUri;
    private String policyUri;
    private String tosUri;
    private Set<String> contacts;
    
    // Additional settings
    private Boolean dynamicallyRegistered;
    private Boolean allowIntrospection;
    private Boolean clearAccessTokensOnRefresh;
    private Boolean reuseRefreshToken;
    
    private Date createdAt;
    private Date updatedAt;
}
