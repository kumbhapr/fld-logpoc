package com.example.oidc.lib.service.impl;

import com.example.oidc.lib.model.AuthorizationCode;
import com.example.oidc.lib.repository.AuthorizationCodeRepository;
import com.example.oidc.lib.service.AuthorizationCodeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class AuthorizationCodeServiceImplTest {

    private AuthorizationCodeService authorizationCodeService;

    @Mock
    private AuthorizationCodeRepository authorizationCodeRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        authorizationCodeService = new AuthorizationCodeServiceImpl(authorizationCodeRepository);
    }

    @Test
    public void testCreateAuthorizationCode() {
        when(authorizationCodeRepository.save(any(AuthorizationCode.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        AuthorizationCode result = authorizationCodeService.createAuthorizationCode(
                "test-client", "user1", "http://localhost:3000/callback",
                Set.of("openid", "profile")
        );

        assertNotNull(result);
        assertEquals("test-client", result.getClientId());
        assertEquals("user1", result.getUserId());
        assertEquals("http://localhost:3000/callback", result.getRedirectUri());
        assertTrue(result.getScopes().contains("openid"));
        assertNotNull(result.getCode());
    }

    @Test
    public void testGetValidAuthorizationCode() {
        AuthorizationCode code = AuthorizationCode.builder()
                .code("test-code-123")
                .clientId("test-client")
                .userId("user1")
                .approved(true)
                .build();

        when(authorizationCodeRepository.findByCode("test-code-123"))
                .thenReturn(Optional.of(code));

        Optional<AuthorizationCode> result = authorizationCodeService.getAuthorizationCode("test-code-123");

        assertTrue(result.isPresent());
        assertEquals("test-code-123", result.get().getCode());
    }

    @Test
    public void testConsumeAuthorizationCode() {
        AuthorizationCode code = AuthorizationCode.builder()
                .id("1")
                .code("test-code-123")
                .build();

        when(authorizationCodeRepository.findByCode("test-code-123"))
                .thenReturn(Optional.of(code));

        authorizationCodeService.consumeAuthorizationCode("test-code-123");

        verify(authorizationCodeRepository, times(1)).deleteById("1");
    }
}
