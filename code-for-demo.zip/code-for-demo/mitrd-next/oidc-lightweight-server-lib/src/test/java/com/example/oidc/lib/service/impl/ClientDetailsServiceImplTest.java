package com.example.oidc.lib.service.impl;

import com.example.oidc.lib.model.ClientDetails;
import com.example.oidc.lib.repository.ClientDetailsRepository;
import com.example.oidc.lib.service.ClientDetailsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class ClientDetailsServiceImplTest {

    private ClientDetailsService clientDetailsService;

    @Mock
    private ClientDetailsRepository clientDetailsRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        clientDetailsService = new ClientDetailsServiceImpl(clientDetailsRepository);
    }

    @Test
    public void testRegisterClient() {
        ClientDetails client = ClientDetails.builder()
                .clientId("test-client")
                .clientSecret("test-secret")
                .clientName("Test Client")
                .redirectUris(Set.of("http://localhost:3000/callback"))
                .build();

        when(clientDetailsRepository.save(any(ClientDetails.class))).thenReturn(client);

        ClientDetails result = clientDetailsService.registerClient(client);

        assertNotNull(result);
        assertEquals("test-client", result.getClientId());
        assertEquals("test-secret", result.getClientSecret());
    }

    @Test
    public void testGetClientByClientId() {
        ClientDetails client = ClientDetails.builder()
                .clientId("test-client")
                .clientSecret("test-secret")
                .build();

        when(clientDetailsRepository.findByClientId("test-client"))
                .thenReturn(Optional.of(client));

        Optional<ClientDetails> result = clientDetailsService.getClientByClientId("test-client");

        assertTrue(result.isPresent());
        assertEquals("test-client", result.get().getClientId());
    }

    @Test
    public void testGetClientByClientIdNotFound() {
        when(clientDetailsRepository.findByClientId("non-existent"))
                .thenReturn(Optional.empty());

        Optional<ClientDetails> result = clientDetailsService.getClientByClientId("non-existent");

        assertFalse(result.isPresent());
    }
}
