# Lightweight OpenID Connect Server Library & Sample IDP

This project provides a lightweight, MongoDB-backed OpenID Connect (OIDC) compliant server library that can be used as a Java library in other Identity Providers (IDPs). It also includes a sample IDP implementation using Spring Boot.

## Project Structure

```
mitrd-next/
├── oidc-lightweight-server-lib/     # Core OIDC Library (reusable)
│   ├── pom.xml
│   └── src/main/java/com/example/oidc/lib/
│       ├── model/                    # Domain models
│       ├── repository/               # MongoDB repositories
│       ├── service/                  # Business logic
│       └── config/                   # Auto-configuration
└── sample-oidc-idp/                  # Sample IDP using the library
    ├── pom.xml
    └── src/main/
        ├── java/com/example/idp/
        │   ├── controller/           # OIDC endpoints
        │   └── config/              # IDP configuration
        └── resources/
            └── templates/            # HTML templates
```

## Features

### OIDC Lightweight Server Library

The library provides the following core OIDC functionality:

1. **Client Management**
   - Register, update, retrieve, and delete OAuth2 clients
   - Support for client credentials and secret management
   - Client metadata management

2. **Authorization Code Flow**
   - Generate authorization codes with configurable expiry
   - Validate and consume authorization codes
   - Support for PKCE (Proof Key for Code Exchange)

3. **Token Management**
   - Generate access tokens
   - Generate refresh tokens
   - JWT-based ID tokens with RS256 signing
   - Token introspection and revocation

4. **JWT Token Service**
   - Create signed ID tokens with custom claims
   - Create access tokens with scopes
   - Create user info JWTs
   - Validate and parse JWT tokens
   - RSA-2048 key pair for signing

5. **User Information Management**
   - Store and retrieve OpenID Connect standard claims
   - Manage user profile information

6. **MongoDB Persistence**
   - All data stored in MongoDB
   - No reliance on Oracle or other databases
   - Easy horizontal scaling

### Sample IDP

The sample IDP demonstrates:

1. **Authentication**
   - Login form with demo accounts (user1, user2, admin)
   - Spring Security integration
   - Session management

2. **OIDC Endpoints**
   - Authorization endpoint (`/authorize`)
   - Token endpoint (`/token`)
   - UserInfo endpoint (`/userinfo`)
   - OpenID Configuration endpoint (`/.well-known/openid-configuration`)

3. **Consent Screen**
   - User consent for authorization
   - Scope approval

4. **Web Interface**
   - Clean, modern HTML templates with Thymeleaf
   - Responsive design

## Prerequisites

- Java 11 or later
- Maven 3.6 or later
- MongoDB 4.0 or later
- Git

## Installation & Setup

### 1. Install MongoDB

```bash
# On macOS (using Homebrew)
brew install mongodb-community
brew services start mongodb-community

# On Ubuntu/Debian
sudo apt-get install mongodb
sudo systemctl start mongodb

# On Docker
docker run -d -p 27017:27017 --name mongodb mongo:latest
```

### 2. Build the Library

```bash
cd /home/prasadk/prasad/work/mitrd-next/oidc-lightweight-server-lib
mvn clean install
```

### 3. Build the Sample IDP

```bash
cd /home/prasadk/prasad/work/mitrd-next/sample-oidc-idp
mvn clean install
```

### 4. Run the Sample IDP

```bash
cd /home/prasadk/prasad/work/mitrd-next/sample-oidc-idp
mvn spring-boot:run
```

The IDP will start at `http://localhost:8080/idp`

## Configuration

### Library Configuration

The library can be configured via application properties:

```yaml
oidc:
  token:
    id-token-validity-seconds: 600        # ID Token lifetime
    access-token-validity-seconds: 3600   # Access Token lifetime
    authorization-code-validity-seconds: 300  # Auth Code lifetime
```

### Sample IDP Configuration

Edit `sample-oidc-idp/src/main/resources/application.yml`:

```yaml
spring:
  data:
    mongodb:
      uri: mongodb://localhost:27017/sample-idp
  
server:
  port: 8080
  servlet:
    context-path: /idp
```

## API Endpoints

### Authorization Endpoint

```
GET /idp/authorize?client_id=CLIENT_ID&response_type=code&redirect_uri=REDIRECT_URI&scope=openid+profile&state=STATE_VALUE&nonce=NONCE_VALUE
```

### Token Endpoint

```
POST /idp/token
Content-Type: application/x-www-form-urlencoded

grant_type=authorization_code&code=CODE&client_id=CLIENT_ID&client_secret=CLIENT_SECRET&redirect_uri=REDIRECT_URI
```

### UserInfo Endpoint

```
GET /idp/userinfo
Authorization: Bearer ACCESS_TOKEN
```

### OpenID Configuration

```
GET /idp/.well-known/openid-configuration
```

## Using the Library in Your Project

### 1. Add Dependency

Add the following to your `pom.xml`:

```xml
<dependency>
    <groupId>com.example.oidc</groupId>
    <artifactId>oidc-lightweight-server-lib</artifactId>
    <version>1.0.0</version>
</dependency>
```

### 2. Configure MongoDB

```yaml
spring:
  data:
    mongodb:
      uri: mongodb://localhost:27017/your-db-name
```

### 3. Inject Services

```java
@RequiredArgsConstructor
public class MyController {
    private final ClientDetailsService clientDetailsService;
    private final AuthorizationCodeService authorizationCodeService;
    private final AccessTokenService accessTokenService;
    private final JWTTokenService jwtTokenService;
    private final UserInfoService userInfoService;
    
    // Use services...
}
```

## Demo Accounts

The sample IDP comes with these pre-configured accounts:

| Username | Password | Role |
|----------|----------|------|
| user1 | password1 | USER |
| user2 | password2 | USER, ADMIN |
| admin | adminpass | ADMIN |

## Testing the OIDC Flow

### 1. Register a Client

Create a client in MongoDB or via the library:

```java
ClientDetails client = ClientDetails.builder()
    .clientId("my-app")
    .clientSecret("my-secret")
    .clientName("My Application")
    .redirectUris(Set.of("http://localhost:3000/callback"))
    .allowedGrantTypes(Set.of("authorization_code"))
    .responseTypes(Set.of("code"))
    .scopes(Set.of("openid", "profile", "email"))
    .build();

clientDetailsService.registerClient(client);
```

### 2. Start Authorization Flow

Visit:
```
http://localhost:8080/idp/authorize?client_id=my-app&response_type=code&redirect_uri=http://localhost:3000/callback&scope=openid+profile&state=xyz123
```

### 3. Login and Authorize

- Login with demo account (e.g., user1/password1)
- Approve the authorization
- Receive authorization code

### 4. Exchange Code for Tokens

```bash
curl -X POST http://localhost:8080/idp/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=authorization_code&code=CODE&client_id=my-app&client_secret=my-secret&redirect_uri=http://localhost:3000/callback"
```

### 5. Get User Information

```bash
curl -H "Authorization: Bearer ACCESS_TOKEN" \
  http://localhost:8080/idp/userinfo
```

## Key Classes

### Models
- `ClientDetails` - OAuth2 client configuration
- `AccessToken` - Access token entity
- `RefreshToken` - Refresh token entity
- `AuthorizationCode` - Authorization code entity
- `UserInfo` - User profile information

### Services
- `ClientDetailsService` - Client management
- `AccessTokenService` - Access token management
- `AuthorizationCodeService` - Authorization code management
- `JWTTokenService` - JWT token creation and validation
- `UserInfoService` - User information management

### Repositories
- `ClientDetailsRepository`
- `AccessTokenRepository`
- `RefreshTokenRepository`
- `AuthorizationCodeRepository`
- `UserInfoRepository`

## Security Considerations

1. **Always use HTTPS** in production
2. **Store client secrets securely** - Consider using encrypted storage
3. **Set appropriate token lifetimes** - Shorter lifetimes for more security
4. **Implement rate limiting** - Prevent brute force attacks
5. **Use secure password hashing** - BCryptPasswordEncoder is used by default
6. **Validate redirect URIs** - Prevent open redirect attacks
7. **Implement CSRF protection** - Spring Security handles this by default

## Extending the Library

### Custom Claims in ID Token

```java
Map<String, Object> claims = new HashMap<>();
claims.put("custom_claim", "value");

JWT idToken = jwtTokenService.createIdToken(
    clientId, userId, issuer, audience, claims
);
```

### Custom User Information

```java
UserInfo userInfo = UserInfo.builder()
    .userId("user1")
    .email("user1@example.com")
    .name("User One")
    .givenName("User")
    .familyName("One")
    .build();

userInfoService.saveUserInfo(userInfo);
```

### Implementing PKCE

The library supports PKCE with authorization codes:

```java
AuthorizationCode authCode = AuthorizationCode.builder()
    .codeChallenge("code_challenge_hash")
    .codeChallengeMethod("S256")
    .build();
```

## Performance Considerations

1. MongoDB indexing on frequently queried fields
2. Token cleanup jobs for expired tokens
3. Caching for client details
4. JWT validation without database lookups

## Production Deployment

1. Use a proper key management system for private keys
2. Implement token cleanup processes
3. Set up monitoring and logging
4. Use load balancing for scalability
5. Configure MongoDB replica sets for high availability
6. Implement rate limiting and DDoS protection

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues.

## Support

For issues or questions, please open an issue in the GitHub repository.

## References

- [OpenID Connect Specification](https://openid.net/connect/)
- [OAuth 2.0 RFC 6749](https://tools.ietf.org/html/rfc6749)
- [JSON Web Tokens (JWT) RFC 7519](https://tools.ietf.org/html/rfc7519)
- [Spring Security Documentation](https://spring.io/projects/spring-security)
- [Spring Data MongoDB](https://spring.io/projects/spring-data-mongodb)
